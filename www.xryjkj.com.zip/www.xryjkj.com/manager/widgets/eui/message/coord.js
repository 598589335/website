var coord = {
    MSIE: "msie",
    SAFARI: "safari!",
    MOZILLA: "mozilla!",
    OPERA: "opera",
    KONW: "konw!",

    PICSHOW_ID: "PICSHOW_ID",           // 列表图片ID
    DELTOOLTIP_ID: "DELTOOLTIP_ID",     //  列表删除ID
    BATCH_DEL_TOOLTIP_ID: "BATCH_DEL_TOOLTIP_ID",       // 批量删除ID
    BATCH_DEL_TOOLTIP_ID_2: "BATCH_DEL_TOOLTIP_ID_2",   // 批量删除样式2的ID

    // ----------------- api ---------------

    // 对外开放的API
    getCoord: function (event, objId, type) {
        return coord.checkScreenArea(event, objId, type);
    },

    // 判断是否超出屏幕
    checkScreenArea: function (event, objId, type) {

        var objWidth = $("#" + objId)[0].offsetWidth;
        var objHeight = $("#" + objId)[0].offsetHeight;

        var coordgetAbsoluteLocation = coord.getAbsoluteLocation(event);
        var absoluteTop = coordgetAbsoluteLocation.absoluteTop;
        var absoluteLeft = coordgetAbsoluteLocation.absoluteLeft;
        var absoluteWidth = coordgetAbsoluteLocation.absoluteWidth;
        var absoluteHeight = coordgetAbsoluteLocation.absoluteHeight;
        //alert(coord.parentScroll(event).TOP);
        //alert(coord.getScreenSize().clientHeight);

        // 检测下边界 大图显示
        if (coord.PICSHOW_ID == type) {
            if (absoluteTop + objHeight > coord.getScreenSize().clientHeight + coord.getScrollTop()) {
                var absoluteTopTemp = coord.getScreenSize().clientHeight + coord.getScrollTop() - objHeight - 2;
                absoluteTop = absoluteTopTemp;
            }
        }

        // 检测下边界 删除提示
        if (coord.DELTOOLTIP_ID == type) {
            // 非浏览器意外的滚动条TOP
            var otherTop = coord.parentScroll(event).TOP;
            //alert((absoluteTop + objHeight + absoluteHeight) + "," + (coord.getScreenSize().clientHeight + coord.getScrollTop()) + "," + otherTop);
            if (absoluteTop + objHeight + absoluteHeight - otherTop > coord.getScreenSize().clientHeight + coord.getScrollTop()) {
                var absoluteTopTemp = coord.getScreenSize().clientHeight + coord.getScrollTop() - objHeight - absoluteHeight - 5;
                var absoluteLeftTemp = absoluteLeft - absoluteWidth;
                absoluteTop = absoluteTopTemp;
                //absoluteLeft = absoluteLeftTemp;
            } else {
                var absoluteTopTemp = absoluteTop;
                absoluteTop = absoluteTopTemp - otherTop;
            }
            //alert(absoluteTop + "," + absoluteLeft);
        }

        // 检测下边界 批量删除提示


        return {
            absoluteTop: absoluteTop,
            absoluteLeft: absoluteLeft,
            absoluteWidth: absoluteWidth,
            absoluteHeight: absoluteHeight
        };
    },

    // 获取当前元素所在body的位置
    // 参数传入的事件
    getAbsoluteLocation: function (event) {
    	var nav = navigator.userAgent.toLowerCase();
    	if(nav.indexOf("msie")!=-1){
    		return coord.getAbsoluteLocationIE(event.srcElement || event);
    	} else {
    		return coord.getAbsoluteLocationOther(event.target || event);
    	}
//        // IE浏览器
//        if (event.srcElement != null) {
//            return coord.getAbsoluteLocationIE(event.srcElement);
//        }
//        // 火狐浏览器
//        if (event.target != null) {
//            return coord.getAbsoluteLocationOther(event.target);
//        }
        
        
    },

    // 获取当前元素所在body的位置
    // 参数传入的元素
    getAbsoluteLocationObj: function (element) {
        if (coord.browserCheck() == coord.MSIE) {
            return coord.getAbsoluteLocationIE(element);
        } else {
            return coord.getAbsoluteLocationOther(element);
        }
    },

    // 获取屏幕大小
    getScreenSize: function () {
        return {
            clientWidth: document.documentElement.clientWidth,
            clientHeight: document.documentElement.clientHeight
        };

    },



    //-------------------- fun --------------------

    // 获取非浏览器滚动条的top,left
    parentScroll: function (event) {
        var element = event.target || event.srcElement || event;

		var top = element.scrollTop;
		var left = element.scrollLeft;
		
		for(;element;element = element.parentNode){
			if(element.scrollTop){
				top += element.scrollTop;
			}
			
			if(element.scrollleft){
				left += element.scrollLeft;
			}
		}
		
        return {
            TOP: top,
            LEFT: left
        };
    },

    // 判断浏览器
    browserCheck: function () {
        if ($.browser.msie) {
            return coord.MSIE;
        }
        else if ($.browser.safari) {
            return coord.SAFARI;
        }
        else if ($.browser.mozilla) {
            return coord.MOZILLA;
        }
        else if ($.browser.opera) {
            return coord.OPERA;
        }
        else {
            return coord.KONW;
        }
    },


    // 滚动条移动距离
    getScrollTop: function () {
        var scrollPos;
        if (typeof window.pageYOffset != 'undefined') //针对Netscape 浏览器
        {
            scrollPos = window.pageYOffset;
        }
        else if (typeof document.compatMode != 'undefined' && document.compatMode != 'BackCompat') {
            scrollPos = document.documentElement.scrollTop;
        }
        else if (typeof document.body != 'undefined') {
            scrollPos = document.body.scrollTop;
        }
        return scrollPos;
    },

    // ie
    getAbsoluteLocationIE: function (element) {
        var offsetParent = element;
        var offsetWidth = element.offsetWidth;
        var offsetHeight = element.offsetHeight
        var offsetTop = 0;
        var offsetLeft = 0;

        while (offsetParent != null && offsetParent.tagName.toUpperCase() != "BODY") {
            offsetLeft += offsetParent.offsetLeft;
            offsetTop += offsetParent.offsetTop;
            offsetParent = offsetParent.offsetParent;
        }

        return {
            absoluteTop: offsetTop,
            absoluteLeft: offsetLeft,
            absoluteWidth: offsetWidth,
            absoluteHeight: offsetHeight
        };
    },

    // 非id
    getAbsoluteLocationOther: function (element) {

        if (element == null) {
            return null;
        }
        if (arguments.length < 1) {
            return null;
        }


        var offsetTop = element.offsetTop;
        var offsetLeft = element.offsetLeft;
        var offsetWidth = element.offsetWidth;
        var offsetHeight = element.offsetHeight;



        while (element = element.offsetParent) {
            offsetTop += element.offsetTop;
            offsetLeft += element.offsetLeft;
        };
        return {
            absoluteTop: offsetTop,
            absoluteLeft: offsetLeft,
            absoluteWidth: offsetWidth,
            absoluteHeight: offsetHeight
        };
    }


};

var getStringWidth={

	_getWidthByText : function(textInfo) {
		// TODO 加入不折行、字体大小、隐藏样式
		var spanNode = $("<span style='display:none;margin:0px;padding:0px;font-size:12px;position:absolute; top:-10000px'>"
				+ textInfo + "</span>").appendTo("body");
		var width = spanNode.outerWidth(true);
		spanNode.remove();
		return width;
	},
	
	/*传递多个P标签的情形*/
	_getMaxWidthOfElements : function(textInfo) {
		var elements = $("<div style='display:none;margin:0px;padding:0px;border:0px;font-size:12px; position:absolute;top:-10000px'></div>").html("<p>"+ textInfo +"</p>").appendTo("body");
		var pNodes = elements.find("p");
		var maxWidth = 0;
		var length = 0;
		if (pNodes.length > 0) {
			for (var i = 0; pNodes.length > i; i++) {
				length = this._getWidthByText(pNodes[i].innerText);
				if (length > maxWidth) {
					maxWidth = length;
				}
			}
		} else {
			maxWidth = this._getWidthByText(textInfo);
		}
		elements.remove();
		return maxWidth;
	}
	
};