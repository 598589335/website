var bubbleTooltip = {
	TYPE_SUCCESS : "TYPE_SUCCESS", // 删除成功操作，无按钮
	TYPE_FAIL : "TYPE_FAIL", // 删除失败操作，有按钮
	TYPE_FAIL_2 : "TYPE_FAIL_2", // 删除失败操作，有按钮
	TYPE_RECOVERABLE : "TYPE_RECOVERABLE", // 移入回收站，有按钮
	TYPE_RECOVERABLE_1 : "TYPE_RECOVERABLE_1", // 移入回收站,带保存按扭
	TYPE_FAIL_1 : "TYPE_FAIL_1", // 删除失败无选择信息操作,无按钮
	TYPE_FAIL_DIY : "TYPE_FAIL_DIY",
	info : "", // 提示信息
	showType : "", // 当前显示类型
	callback : null,
	callback1 : null,
	buttext1:null,
	buttext2:null,

	/** 显示冒泡提示 */
	show : function(info, type, callback, callback1, buttext1, buttext2) {
		/*
		 * bubbleTooltip.showType = type; if (bubbleTooltip.showType ==
		 * bubbleTooltip.TYPE_RECOVERABLE || bubbleTooltip.showType ==
		 * bubbleTooltip.TYPE_FAIL) { bubbleTooltip.runShow(info, type,
		 * callback); } else
		 */
		if ($("#bubbleTooltipSuccess").attr("id") == null
				&& $("#bubbleTooltipFail1").attr("id") == null
				&& $("#bubbleTooltipFail").attr("id") == null
				&& $("#bubbleTooltipFail").attr("id") == null) {
			bubbleTooltip.runShow(info, type, callback, callback1, buttext1, buttext2);
		}
	},

	/** 创建冒泡显示 */
	runShow : function(info, type, callback, callback1, buttext1, buttext2) {
		bubbleTooltip.showType = type;
		bubbleTooltip.info = (info == null ? "" : info);
		this.callback = callback;
		this.callback1 = callback1;
		this.buttext1=buttext1;
		this.buttext2=buttext2;
		bubbleTooltip.dispose();
		bubbleTooltip.create();
	},

	/** 对外开放的类型 */
	getType : function() {
		return {
			TYPE_SUCCESS : bubbleTooltip.TYPE_SUCCESS,
			TYPE_FAIL : bubbleTooltip.TYPE_FAIL,
			TYPE_FAIL_2 : bubbleTooltip.TYPE_FAIL_2,
			TYPE_RECOVERABLE : bubbleTooltip.TYPE_RECOVERABLE,
			TYPE_RECOVERABLE_1 : bubbleTooltip.TYPE_RECOVERABLE_1,
			TYPE_FAIL_1 : bubbleTooltip.TYPE_FAIL_1,
			TYPE_FAIL_DIY : bubbleTooltip.TYPE_FAIL_DIY
		};
	},
	
	/*获取信息提示框合适宽度*/
	_getCurrentWidth:function(){
	//TODO 冒泡提示情况，有按钮，无按钮
		 var width = getStringWidth._getMaxWidthOfElements(bubbleTooltip.info);
		 if("TYPE_RECOVERABLE"==bubbleTooltip.showType||"TYPE_RECOVERABLE_1"==bubbleTooltip.showType||"TYPE_FAIL"==bubbleTooltip.showType||"TYPE_FAIL_2"==bubbleTooltip.showType){//有按钮，需比较
			   if(width>=115){//115为确认取消按钮占用的宽度
						width=width+80;//80为两边DIV占用的宽度
			   }else{
						width=115+80;
				}
		 }else{//无按钮，默认为文字宽度
			   width=width+80;
			  }
			  return width;
},
    /*判断浏览器版本*/
    _getStyles:function(){
        if (!($.browser.msie && ($.browser.version == 6.0 || $.browser.version == 7.0))) {// 不是IE6和IE7
			return 'position:absolute; z-index:19999;';
		} else {
			    var width = this._getCurrentWidth();
			    return 'position:absolute;z-index:19999;width:' + width + 'px;';
		}
    },

	/** 样式添加 */
	create : function() {
		switch (bubbleTooltip.showType) {
			case bubbleTooltip.TYPE_SUCCESS :
				bubbleTooltip.createTypeSucess();
				break;
			case bubbleTooltip.TYPE_FAIL :
				bubbleTooltip.crateTypeFail();
				break;
			case bubbleTooltip.TYPE_FAIL_2 :
				bubbleTooltip.crateTypeFail2();
				break;
			case bubbleTooltip.TYPE_RECOVERABLE :
				bubbleTooltip.crateTypeRecoverable();
				break;
			case bubbleTooltip.TYPE_RECOVERABLE_1 :
				bubbleTooltip.crateTypeRecoverable1();
				break;
			case bubbleTooltip.TYPE_FAIL_1 :
				bubbleTooltip.createTypeFail1();
				break;
			case bubbleTooltip.TYPE_FAIL_DIY :
				
				bubbleTooltip.createDIY();
				break;
		}
		bubbleTooltip.getCentre();
	},

	/** 删除失败无选择操作 */
	createTypeFail1 : function() {
		$("body").append('<div id="bubbleTooltipFail1" style="'
				+ this._getStyles()
				+ '" class="zzp-pop-alert zzp-alert-fault02">'
				+ ' <div class="zzp-alert-l">'
				+ '     <div class="zzp-alert-r">' + bubbleTooltip.info
				+ '</div>' + ' </div>' + '</div>');
	},

	/** 删除成功操作 */
	createTypeSucess : function() {
		$("body").append('<div id="bubbleTooltipSuccess" style="'
				+ this._getStyles()
				+ '" class="zzp-pop-alert zzp-alert-correct">'
				+ '<div class="zzp-alert-l">' + '<div class="zzp-alert-r">'
				+ bubbleTooltip.info + '</div>' + '</div>' + '</div>');
	},

	/** 删除失败操作 */
	crateTypeFail : function() {
		// ding_cq 2012.5.26 更改新样式,为了提示信息换行 add
		$("body")
				.append('<div id="bubbleTooltipFail" style="'
						+ this._getStyles()
						+ '" class="zzp-alert-confirm02 zzp-alert-fault02">'
						+ '<div class="zzp-pop-top">'
						+ '<div class="pop-top-l">'
						+ '<div class="pop-top-r"></div>'
						+ '</div>'
						+ '</div>'
						+ '<div class="zzp-pop-center">'
						+ '<div class="pop-cen-r">'
						+ '<div class="pop-content-wrap">'
						+ '<div class="pop-content-body">'
						+ '<p>'
						+ bubbleTooltip.info
						+ '</p>'
						+ '<p class="zzp-indent">'
						+ '<span class="zzp-btn-filter zzp-retry"><a href="javascript:void(0)" onclick="bubbleTooltip.tooltipFailRetry()" title="重试"><span></span><em>重试</em></a></span>'
						+ '<span class="or">或</span>'
						+ '<span class="zzp-btn-filter zzp-cancel"><a href="javascript:void(0)" onclick="bubbleTooltip.tooltipFailCancal()" title="取消"><span></span><em>取消</em></a></span>'
						+ '</p>' + '</div>' + '</div>' + '</div>' + '</div>'
						+ '<div class="zzp-pop-bottom">'
						+ '<div class="pop-bot-l">'
						+ '<div class="pop-bot-r"></div>' + '</div>' + '</div>'
						+ '</div>');
	},

	/** 删除中的重试 */
	tooltipFailRetry : function() {
		// alert("调用重试接口");
		if (typeof(this.callback) == 'string') {
			eval("(" + this.callback + ")");
		} else {
			this.callback();
		}
		$("#bubbleTooltipFail").fadeOut("slow", function() {
					bubbleTooltip.dispose();
				});
		$("#bubbleTooltipDIY").fadeOut("slow", function() {
					bubbleTooltip.dispose();
				});
	},

	/** 删除操作中的取消 */
	tooltipFailCancal : function() {
		if(this.callback1){
			if (typeof(this.callback1) == 'string') {
				eval("(" + this.callback1 + ")");
			} else {
				this.callback1();
			}
		}
		$("#bubbleTooltipFail").fadeOut("slow", function() {
					bubbleTooltip.dispose();
				})
		$("#bubbleTooltipDIY").fadeOut("slow", function() {
					bubbleTooltip.dispose();
				});

	},

	/** 导入导出失败操作 */
	crateTypeFail2 : function() {
		// ding_cq 2012.5.26 更改新样式,为了提示信息换行 add
		$("body")
				.append('<div id="bubbleTooltipFail2" style="'
						+ this._getStyles()
						+ '" class="zzp-alert-confirm02 zzp-alert-fault02">'
						+ '<div class="zzp-pop-top">'
						+ '<div class="pop-top-l">'
						+ '<div class="pop-top-r"></div>'
						+ '</div>'
						+ '</div>'
						+ '<div class="zzp-pop-center">'
						+ '<div class="pop-cen-r">'
						+ '<div class="pop-content-wrap">'
						+ '<div class="pop-content-body">'
						+ '<p>'
						+ bubbleTooltip.info
						+ '</p>'
						+ '<p class="zzp-indent">'
						+ '<span class="zzp-btn-filter zzp-retry"><a href="javascript:void(0)" onclick="bubbleTooltip.tooltipFailRetry2()" title="下载失败记录"><span></span><em>下载失败记录</em></a></span>'
						+ '<span class="or">或</span>'
						+ '<span class="zzp-btn-filter zzp-cancel"><a href="javascript:void(0)" onclick="bubbleTooltip.tooltipFailCancal2()" title="关闭"><span></span><em>关闭</em></a></span>'
						+ '</p>' + '</div>' + '</div>' + '</div>' + '</div>'
						+ '<div class="zzp-pop-bottom">'
						+ '<div class="pop-bot-l">'
						+ '<div class="pop-bot-r"></div>' + '</div>' + '</div>'
						+ '</div>');
	},
	/*自定义*/
	createDIY:function(){
		$("body").append('<div class="zzp-alert-pop zzp-pop-success" style="width:350px;" id="bubbleTooltipDIY">'
					+'<div class="zzp-pop-top">'
						+'<div class="pop-top-l">'
							+'<div class="pop-top-r"></div>'
						+'</div>'
					+'</div>'
					+'<div class="zzp-pop-center">'
						+'<div class="pop-cen-r">'
							+'<div class="pop-content-wrap">'
								+'<div class="pop-content-body">'
									+'<p>'
									+ bubbleTooltip.info
									
									+'</p><p class="zzp-indent">'
										+'<span class="zzp-btn-filter zzp-retry"><a href="javascript:void(0)" onclick="bubbleTooltip.tooltipFailRetry()" title=""><span></span><em>'+this.buttext1+'</em></a></span>'
										+'<span class="or">或</span>'
										+'<span class="zzp-btn-filter zzp-cancel"><a href="javascript:void(0)" onclick="bubbleTooltip.tooltipFailCancal()" title=""><span></span><em>'+this.buttext2+'</em></a></span>'
									+'</p></div></div></div></div>'
									+'<div class="zzp-pop-bottom">'
						+'<div class="pop-bot-l">'
							+'<div class="pop-bot-r"></div>'
						+'</div>'
					+'</div>'
				+'</div>'
									);
	},

	/** 导入导出失败的下载失败记录 */
	tooltipFailRetry2 : function() {
		// alert("调用重试接口");
		if (typeof(this.callback) == 'string') {
			eval("(" + this.callback + ")");
		} else {
			this.callback();
		}

		$("#bubbleTooltipFail2").fadeOut("slow", function() {
					bubbleTooltip.dispose();
				})
	},

	/** 导入导出失败中的关闭 */
	tooltipFailCancal2 : function() {
		$("#bubbleTooltipFail2").fadeOut("slow", function() {
					bubbleTooltip.dispose();
				})
	},
	
	/** ding_cq 2012.5.14 add begin 移入回收站,有确认,取消 */
	crateTypeRecoverable1 : function() {
		$("body")
				.append('<div id="bubbleTooltipRecoverable1" style="'
						+ this._getStyles()
						+ '" class="zzp-alert-confirm02">'
						+ '<div class="zzp-pop-top">'
						+ '<div class="pop-top-l">'
						+ '<div class="pop-top-r"></div>'
						+ '</div>'
						+ '</div>'
						+ '<div class="zzp-pop-center">'
						+ '<div class="pop-cen-r">'
						+ '<div class="pop-content-wrap">'
						+ '<div class="pop-content-body">'
						+ '<p>'
						+ bubbleTooltip.info
						+ '</p>'
						+ '<p class="zzp-indent">'
						+ '<span class="zzp-btn-filter zzp-retry"><a href="javascript:void(0)" onclick="bubbleTooltip.tooltipRecoverableRetry1()" title="保存"><span></span><em>保存</em></a></span>'
						+ '<span class="or">或</span>'
						+ '<span class="zzp-btn-filter zzp-cancel"><a href="javascript:void(0)" onclick="bubbleTooltip.tooltipRecoverableCancal1()" title="取消"><span></span><em>取消</em></a></span>'
						+ '</p>' + '</div>' + '</div>' + '</div>' + '</div>'
						+ '<div class="zzp-pop-bottom">'
						+ '<div class="pop-bot-l">'
						+ '<div class="pop-bot-r"></div>' + '</div>' + '</div>'
						+ '</div>');
	},
	/** 移入回收站中的确定 */
	tooltipRecoverableRetry1 : function() {
		// alert("调用移入回收站确认接口");
		if (typeof(this.callback) == 'string') {
			eval("(" + this.callback + ")");
		} else {
			this.callback();
		}
		$("#bubbleTooltipRecoverable1").fadeOut("slow", function() {
					bubbleTooltip.dispose();
				})
	},

	/** 移入回收站操作中的取消 */
	tooltipRecoverableCancal1 : function() {
		if (typeof(this.callback1) == 'string') {
			eval("(" + this.callback1 + ")");
		} else {
			this.callback1 && this.callback1();
		}
		$("#bubbleTooltipRecoverable1").fadeOut("slow", function() {
					bubbleTooltip.dispose();
				})
	},
	/** ding_cq 2012.5.14 add begin 移入回收站,有确认,取消 */

	/** 移入回收站 */
	crateTypeRecoverable : function() {
		$("body")
				.append('<div id="bubbleTooltipRecoverable" style="'
						+ this._getStyles()
						+ '" class="zzp-alert-confirm02">'
						+ '<div class="zzp-pop-top">'
						+ '<div class="pop-top-l">'
						+ '<div class="pop-top-r"></div>'
						+ '</div>'
						+ '</div>'
						+ '<div class="zzp-pop-center">'
						+ '<div class="pop-cen-r">'
						+ '<div class="pop-content-wrap">'
						+ '<div class="pop-content-body">'
						+ '<p>'
						+ bubbleTooltip.info
						+ '</p>'
						+ '<p class="zzp-indent">'
						+ '<span class="zzp-btn-filter zzp-retry"><a href="javascript:void(0)" onclick="bubbleTooltip.tooltipRecoverableRetry()" title="确定"><span></span><em>确定</em></a></span>'
						+ '<span class="or">或</span>'
						+ '<span class="zzp-btn-filter zzp-cancel"><a href="javascript:void(0)" onclick="bubbleTooltip.tooltipRecoverableCancal()" title="取消"><span></span><em>取消</em></a></span>'
						+ '</p>' + '</div>' + '</div>' + '</div>' + '</div>'
						+ '<div class="zzp-pop-bottom">'
						+ '<div class="pop-bot-l">'
						+ '<div class="pop-bot-r"></div>' + '</div>' + '</div>'
						+ '</div>');
	},

	/** 移入回收站中的确定 */
	tooltipRecoverableRetry : function() {
		// alert("调用移入回收站确认接口");
		if (typeof(this.callback) == 'string') {
			eval("(" + this.callback + ")");
		} else {
			this.callback();
		}
		$("#bubbleTooltipRecoverable").fadeOut("slow", function() {
					bubbleTooltip.dispose();
				})
	},

	/** 移入回收站操作中的取消 */
	tooltipRecoverableCancal : function() {
		$("#bubbleTooltipRecoverable").fadeOut("slow", function() {
					bubbleTooltip.dispose();
				})
	},

	/** dispose */
	dispose : function() {
		$("#bubbleTooltipSuccess").remove();
		$("#bubbleTooltipFail").remove();
		$("#bubbleTooltipRecoverable").remove();
		$("#bubbleTooltipFail1").remove();
		$("#bubbleTooltipRecoverable1").remove();
		$("#bubbleTooltipFail2").remove();
		$("#bubbleTooltipDIY").remove();
	},

	/** 获取居中位置 */
	getCentre : function() {
		var clientWidth = coord.getScreenSize().clientWidth;
		var clientHeight = coord.getScreenSize().clientHeight;
		var elementWidth = 0;
		var elementHeight = 0;
		var element = null;

		switch (bubbleTooltip.showType) {
			case bubbleTooltip.TYPE_FAIL_1 :
				element = $("#bubbleTooltipFail1")[0];
				elementWidth = element.offsetWidth;
				elementHeight = element.offsetHeight;
				break;
			case bubbleTooltip.TYPE_SUCCESS :
				element = $("#bubbleTooltipSuccess")[0];
				elementWidth = element.offsetWidth;
				elementHeight = element.offsetHeight;
				break;
			case bubbleTooltip.TYPE_FAIL :
				element = $("#bubbleTooltipFail")[0];
				elementWidth = element.offsetWidth;
				elementHeight = element.offsetHeight;
				break;
			case bubbleTooltip.TYPE_FAIL_2 :
				element = $("#bubbleTooltipFail2")[0];
				elementWidth = element.offsetWidth;
				elementHeight = element.offsetHeight;
				break;
			case bubbleTooltip.TYPE_RECOVERABLE :
				element = $("#bubbleTooltipRecoverable")[0];
				elementWidth = element.offsetWidth;
				elementHeight = element.offsetHeight;
				break;
			case bubbleTooltip.TYPE_RECOVERABLE_1 :
				element = $("#bubbleTooltipRecoverable1")[0];
				elementWidth = element.offsetWidth;
				elementHeight = element.offsetHeight;
				break;
			case bubbleTooltip.TYPE_FAIL_DIY :
				element = $("#bubbleTooltipDIY")[0];
				elementWidth = element.offsetWidth;
				elementHeight = element.offsetHeight;
				break;
		}
		// alert(coord.getScrollTop());
		$(element).css("position","absolute");
		$(element).css("top",
				(clientHeight - elementHeight) / 2 + coord.getScrollTop());
		$(element).css("left", (clientWidth - elementWidth) / 2);
		$(element).css("display", "none");

		if (bubbleTooltip.showType == bubbleTooltip.TYPE_SUCCESS
				|| bubbleTooltip.showType == bubbleTooltip.TYPE_FAIL_1) {
			// $(element).show().fadeOut(2000, function () {
			// bubbleTooltip.dispose();
			// });

			$(element).fadeIn(1000, function() {
						setTimeout(function() {
									$(element).fadeOut(1000, function() {
												bubbleTooltip.dispose();
											});
								}, 1000);
					})
		} else {
			$(element).fadeIn(1000, function() {

					})
		}

	}
}