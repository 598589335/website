﻿$(function() {
    /*
    $("#j_username, #name").blur(function() {
        validateName($(this)); //
    });
    

    $("#j_password").blur(function() {
        var p = $(this).val();
        if (p == null || p == '') {
            showMeg("请输入密码！");
            $(this).focus();
        }
    });
	


    function validateName(inputEle) {
        var userNameEle = $(inputEle);
        var n = userNameEle.val();
        n = $.trim(n);
        userNameEle.val(n);

        if (n == null || n == '') {
            showMeg("请输入用户名!");
            userNameEle.focus();
            return false;
        } else {
            if (/.+@.+\..+/.test(n)) {
            } else {
                if (isCrm) {
                     return true;
			    }
                showMeg("请输入有效的用户名！");
                userNameEle.focus();
                return false;
            }
        }

        return true;
    }
	*/

});


