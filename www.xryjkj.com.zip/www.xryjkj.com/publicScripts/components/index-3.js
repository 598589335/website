var FrontColumns_navigation01={currentColumn:0,isShowSecondColumn:"",compId:"",addClickEvent:function(){$(".navMenu li").each(function(a){$(this).bind("click",function(){$("#columns-"+FrontColumns_navigation01.compId+"-"+FrontColumns_navigation01.currentColumn).removeClass("navMenubg"+FrontColumns_navigation01.currentColumn);$(this).addClass("navMenubg"+a);if(FrontColumns_navigation01.isShowSecondColumn.length>0){$("#secondColumns-"+FrontColumns_navigation01.compId+"-"+FrontColumns_navigation01.currentColumn).hide();$("#secondColumns-"+FrontColumns_navigation01.compId+"-"+a).show()}FrontColumns_navigation01.currentColumn=a})})},addMouseOverEvent:function(){$(".navMenu li").each(function(a){$(this).bind("mouseover",function(){$("#columns-"+FrontColumns_navigation01.compId+"-"+FrontColumns_navigation01.currentColumn).removeClass("navMenubg"+FrontColumns_navigation01.currentColumn);$(this).addClass("navMenubg"+a);if(FrontColumns_navigation01.isShowSecondColumn.length>0){$("#secondColumns-"+FrontColumns_navigation01.compId+"-"+FrontColumns_navigation01.currentColumn).hide();$("#secondColumns-"+FrontColumns_navigation01.compId+"-"+a).show()}})})},addMouseOutEvent:function(){$(".navMenu li").each(function(a){$(this).bind("mouseout",function(){$(this).removeClass("navMenubg"+a);$("#columns-"+FrontColumns_navigation01.compId+"-"+FrontColumns_navigation01.currentColumn).addClass("navMenubg"+FrontColumns_navigation01.currentColumn);if(FrontColumns_navigation01.isShowSecondColumn.length>0){$("#secondColumns-"+FrontColumns_navigation01.compId+"-"+a).hide();$("#secondColumns-"+FrontColumns_navigation01.compId+"-"+FrontColumns_navigation01.currentColumn).show()}})})},setSelectedColumn:function(a){var b=this.getUrlParam(a);if(b!=null){this.currentColumn=b}},setFocusColumn:function(){$("#columns-"+FrontColumns_navigation01.compId+"-"+this.currentColumn).addClass("navMenubg"+this.currentColumn);if(this.isShowSecondColumn.length>0){$("#secondColumns-"+FrontColumns_navigation01.compId+"-"+this.currentColumn).show()}},getUrlParam:function(a){var b=new RegExp("(^|&)"+a+"=([^&]*)(&|$)");var c=window.location.toString().match(b);if(c!=null){return unescape(c[2])}return null},init:function(c,b,a){this.compId=c;this.isShowSecondColumn=a;this.setSelectedColumn(c+"-"+b);this.addClickEvent();this.addMouseOverEvent();this.addMouseOutEvent();this.setFocusColumn()},extEvents:function(d,a){var b=this.getUrlParam(d+"FirstColumnId");var c=this.getUrlParam(d+"SecondColumnId");if(b==null){b=$("#"+d+" ul.nav-first .first").attr("id")}else{b="columns"+b}if(c==null){c=$("#"+d+" #"+b+" .nav-second .nav-sec-main ul li:first a").attr("id")}else{c="cols"+c}$("#"+d+" #"+b).addClass("current");$("#"+d+" #"+c).addClass("current-a");$("#"+d+" #"+b+"Sub").show();if(a){$("#"+d+" ul.nav-first li[id^='columns']").hover(function(){if($(this).attr("id")!=b){$("#"+d+" #"+b).removeClass("current");$("#"+d+" #"+b+"Sub").hide();$(this).addClass("current");$("#"+d+" #"+$(this).attr("id")+"Sub").show();if(!$(this).find(".nav-second .nav-sec-main a").hasClass("current-a")){$(this).find(".nav-second .nav-sec-main a:first").addClass("current-a")}}},function(){$(this).removeClass("current");$("#"+d+" #"+$(this).attr("id")+"Sub").hide();$("#"+d+" #"+b).addClass("current");$("#"+d+" #"+b+"Sub").show()});$("#"+d+" ul.nav-first li[id^='columns']").click(function(){$("#"+d+" #"+b).removeClass("current");$("#"+d+" #"+b+"Sub").hide();$(this).addClass("current");$("#"+d+" #"+$(this).attr("id")+"Sub").show();b=$("#"+d+" ul.nav-first li.current").attr("id")});$("#"+d+" ul.nav-first .nav-second .nav-sec-main a").click(function(){$(this).parent().parent().find("a").removeClass("current-a");$(this).addClass("current-a");var e=$(this).parents(".nav-second").attr("id");if(e!==b+"Sub"){$("#"+d+" #"+b).removeClass("current");$("#"+d+" #"+b+"Sub").hide();b=e.substring(0,e.length-3);$("#"+d+" #"+b).addClass("current");$("#"+d+" #"+e).show()}})}else{$("#"+d+" ul.nav-first li[id^='columns']").hover(function(){if($(this).attr("id")!=b){$("#"+d+" #"+b).removeClass("current");$(this).addClass("current")}},function(){$(this).removeClass("current");$("#"+d+" #"+b).addClass("current")});$("#"+d+" ul.nav-first li[id^='columns']").click(function(){$("#"+d+" #"+b).removeClass("current");$(this).addClass("current");b=$("#"+d+" ul.nav-first li.current").attr("id")})}},ddlevelsmenu:{enableshim:true,arrowpointers:{downarrow:["../images/columns/arrow-down.gif",11,7],rightarrow:["../images/columns/arrow-right.gif",12,12],showarrow:{toplevel:true,sublevel:true}},hideinterval:200,effects:{enableswipe:true,enablefade:true,duration:200},httpsiframesrc:"blank.htm",topmenuids:[],topitems:{},subuls:{},lastactivesubul:{},topitemsindex:-1,ulindex:-1,hidetimers:{},shimadded:false,nonFF:!/Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent),getoffset:function(b,a){return(b.offsetParent)?b[a]+this.getoffset(b.offsetParent,a):b[a]},getoffsetof:function(a){a._offsets={left:this.getoffset(a,"offsetLeft"),top:this.getoffset(a,"offsetTop")}},getwindowsize:function(){this.docwidth=window.innerWidth?window.innerWidth-10:this.standardbody.clientWidth-10;this.docheight=window.innerHeight?window.innerHeight-15:this.standardbody.clientHeight-18},gettopitemsdimensions:function(){for(var a=0;a<this.topmenuids.length;a++){var d=this.topmenuids[a];for(var b=0;b<this.topitems[d].length;b++){var e=this.topitems[d][b];var c=document.getElementById(e.getAttribute("rel"));e._dimensions={w:e.offsetWidth,h:e.offsetHeight,submenuw:c.offsetWidth,submenuh:c.offsetHeight}}}},isContained:function(a,b){var b=window.event||b;var d=b.relatedTarget||((b.type=="mouseover")?b.fromElement:b.toElement);while(d&&d!=a){try{d=d.parentNode}catch(b){d=a}}if(d==a){return true}else{return false}},addpointer:function(d,f,a,c){var e=document.createElement("img");e.src=a[0];e.style.width=a[1]+"px";e.style.height=a[2]+"px";if(f=="FrontColumn_navigation01_rightarrowpointer"){e.style.left=d.offsetWidth-a[2]-2+"px"}e.className=f;var b=d.childNodes[d.firstChild.nodeType!=1?1:0];if(b&&b.tagName=="SPAN"){d=b}if(c=="before"){d.insertBefore(e,d.firstChild)}else{d.appendChild(e)}},css:function(b,a,c){var d=new RegExp("(^|\\s+)"+a+"($|\\s+)","ig");if(c=="check"){return d.test(b.className)}else{if(c=="remove"){b.className=b.className.replace(d,"")}else{if(c=="add"&&!d.test(b.className)){b.className+=" "+a}}}},addshimmy:function(b){var c=(!window.opera)?document.createElement("iframe"):document.createElement("div");c.className="FrontColumn_navigation01_ddiframeshim";c.setAttribute("src",location.protocol=="https:"?this.httpsiframesrc:"about:blank");c.setAttribute("frameborder","0");b.appendChild(c);try{c.style.filter="progid:DXImageTransform.Microsoft.Alpha(style=0,opacity=0)"}catch(a){}return c},positionshim:function(g,c,a,f,e){if(g._istoplevel){var e=window.pageYOffset?window.pageYOffset:this.standardbody.scrollTop;var d=g._offsets.top-e;var b=e+this.docheight-g._offsets.top-g._dimensions.h;if(d>0){this.shimmy.topshim.style.left=f+"px";this.shimmy.topshim.style.top=e+"px";this.shimmy.topshim.style.width="99%";this.shimmy.topshim.style.height=d+"px"}if(b>0){this.shimmy.bottomshim.style.left=f+"px";this.shimmy.bottomshim.style.top=g._offsets.top+g._dimensions.h+"px";this.shimmy.bottomshim.style.width="99%";this.shimmy.bottomshim.style.height=b+"px"}}},hideshim:function(){this.shimmy.topshim.style.width=this.shimmy.bottomshim.style.width=0;this.shimmy.topshim.style.height=this.shimmy.bottomshim.style.height=0},buildmenu:function(d,f,c,e,a,b){f._master=d;f._pos=e;f._istoplevel=a;if(a){this.addEvent(f,function(g){FrontColumns_navigation01.ddlevelsmenu.hidemenu(FrontColumns_navigation01.ddlevelsmenu.subuls[this._master][parseInt(this._pos)])},"click")}this.subuls[d][e]=c;f._dimensions={w:f.offsetWidth,h:f.offsetHeight,submenuw:c.offsetWidth,submenuh:c.offsetHeight};this.getoffsetof(f);c.style.visibility="hidden";this.addEvent(f,function(j){if(!FrontColumns_navigation01.ddlevelsmenu.isContained(this,j)){var h=FrontColumns_navigation01.ddlevelsmenu.subuls[this._master][parseInt(this._pos)];if(this._istoplevel){FrontColumns_navigation01.ddlevelsmenu.css(this,"selected","add");clearTimeout(FrontColumns_navigation01.ddlevelsmenu.hidetimers[this._master][this._pos])}FrontColumns_navigation01.ddlevelsmenu.getoffsetof(f);var l=window.pageXOffset?window.pageXOffset:FrontColumns_navigation01.ddlevelsmenu.standardbody.scrollLeft;var i=window.pageYOffset?window.pageYOffset:FrontColumns_navigation01.ddlevelsmenu.standardbody.scrollTop;var n=this._offsets.left+this._dimensions.submenuw+(this._istoplevel&&b=="topbar"?0:this._dimensions.w);var g=this._offsets.top+this._dimensions.submenuh;var m=(this._istoplevel?this._offsets.left+(b=="sidebar"?this._dimensions.w:0):this._dimensions.w);if(n-l>FrontColumns_navigation01.ddlevelsmenu.docwidth){m+=-this._dimensions.submenuw+(this._istoplevel&&b=="topbar"?this._dimensions.w:-this._dimensions.w)}h.style.left=m+"px";var k=(this._istoplevel?this._offsets.top+(b=="sidebar"?0:this._dimensions.h):this.offsetTop);if(g-i>FrontColumns_navigation01.ddlevelsmenu.docheight){if(this._dimensions.submenuh<this._offsets.top+(b=="sidebar"?this._dimensions.h:0)-i){k+=-this._dimensions.submenuh+(this._istoplevel&&b=="topbar"?-this._dimensions.h:this._dimensions.h)}else{k+=-(this._offsets.top-i)+(this._istoplevel&&b=="topbar"?-this._dimensions.h:0)}}h.style.top=k+"px";if(FrontColumns_navigation01.ddlevelsmenu.enableshim&&(FrontColumns_navigation01.ddlevelsmenu.effects.enableswipe==false||FrontColumns_navigation01.ddlevelsmenu.nonFF)){FrontColumns_navigation01.ddlevelsmenu.positionshim(f,h,b,l,i)}else{h.FFscrollInfo={x:l,y:i}}FrontColumns_navigation01.ddlevelsmenu.showmenu(f,h,b)}},"mouseover");this.addEvent(f,function(h){var g=FrontColumns_navigation01.ddlevelsmenu.subuls[this._master][parseInt(this._pos)];if(this._istoplevel){if(!FrontColumns_navigation01.ddlevelsmenu.isContained(this,h)&&!FrontColumns_navigation01.ddlevelsmenu.isContained(g,h)){FrontColumns_navigation01.ddlevelsmenu.hidemenu(g)}}else{if(!this._istoplevel&&!FrontColumns_navigation01.ddlevelsmenu.isContained(this,h)){FrontColumns_navigation01.ddlevelsmenu.hidemenu(g)}}},"mouseout")},setopacity:function(a,b){a.style.opacity=b;if(typeof a.style.opacity!="string"){a.style.MozOpacity=b;if(a.filters){a.style.filter="progid:DXImageTransform.Microsoft.alpha(opacity="+b*100+")"}}},showmenu:function(d,b,a){if(this.effects.enableswipe||this.effects.enablefade){if(this.effects.enableswipe){var c=(d._istoplevel&&a=="topbar")?d._dimensions.submenuh:d._dimensions.submenuw;b.style.width=b.style.height=0;b.style.overflow="hidden"}if(this.effects.enablefade){this.setopacity(b,0)}b._curanimatedegree=0;b.style.visibility="visible";clearInterval(b._animatetimer);b._starttime=new Date().getTime();b._animatetimer=setInterval(function(){FrontColumns_navigation01.ddlevelsmenu.revealmenu(d,b,c,a)},10)}else{b.style.visibility="visible"}},revealmenu:function(e,c,d,b){var a=new Date().getTime()-c._starttime;if(a<this.effects.duration){if(this.effects.enableswipe){if(c._curanimatedegree==0){c.style[e._istoplevel&&b=="topbar"?"width":"height"]="auto"}c.style[e._istoplevel&&b=="topbar"?"height":"width"]=(c._curanimatedegree*d)+"px"}if(this.effects.enablefade){this.setopacity(c,c._curanimatedegree)}}else{clearInterval(c._animatetimer);if(this.effects.enableswipe){c.style.width="auto";c.style.height="auto";c.style.overflow="visible"}if(this.effects.enablefade){this.setopacity(c,1);c.style.filter=""}if(this.enableshim&&c.FFscrollInfo){this.positionshim(e,c,b,c.FFscrollInfo.x,c.FFscrollInfo.y)}}c._curanimatedegree=(1-Math.cos((a/this.effects.duration)*Math.PI))/2},hidemenu:function(a){if(typeof a._pos!="undefined"){this.css(this.topitems[a._master][parseInt(a._pos)],"selected","remove");if(this.enableshim){this.hideshim()}}clearInterval(a._animatetimer);a.style.visibility="hidden"},addEvent:function(b,c,a){if(b.addEventListener){b.addEventListener(a,c,false)}else{if(b.attachEvent){b.attachEvent("on"+a,function(){return c.call(b,window.event)})}}},domready:function(a){if(dd_domreadycheck){a();return}if(document.addEventListener){document.addEventListener("DOMContentLoaded",function(){document.removeEventListener("DOMContentLoaded",arguments.callee,false);a();dd_domreadycheck=true},false)}else{if(document.attachEvent){if(document.documentElement.doScroll&&window==window.top){(function(){if(dd_domreadycheck){a();return}try{document.documentElement.doScroll("left")}catch(b){setTimeout(arguments.callee,0);return}a();dd_domreadycheck=true})()}}}if(document.attachEvent&&parent.length>0){this.addEvent(window,function(){a()},"load")}},init:function(b,e){this.standardbody=(document.compatMode=="CSS1Compat")?document.documentElement:document.body;this.topitemsindex=-1;this.ulindex=-1;this.topmenuids.push(b);this.topitems[b]=[];this.subuls[b]=[];this.hidetimers[b]=[];if(this.enableshim&&!this.shimadded){this.shimmy={};this.shimmy.topshim=this.addshimmy(document.body);this.shimmy.bottomshim=this.addshimmy(document.body);this.shimadded=true}var j=document.getElementById(b);var d=j.getElementsByTagName("a");this.getwindowsize();for(var g=0;g<d.length;g++){if(d[g].getAttribute("rel")){this.topitemsindex++;this.ulindex++;var l=d[g];this.topitems[b][this.topitemsindex]=l;var m=document.getElementById(l.getAttribute("rel"));m.style.zIndex=2000;m._master=b;m._pos=this.topitemsindex;this.addEvent(m,function(){FrontColumns_navigation01.ddlevelsmenu.hidemenu(this)},"click");var n=(e=="sidebar")?"FrontColumn_navigation01_rightarrowpointer":"FrontColumn_navigation01_downarrowpointer";var h=(e=="sidebar")?this.arrowpointers.rightarrow:this.arrowpointers.downarrow;if(this.arrowpointers.showarrow.toplevel){this.addpointer(l,n,h,(e=="sidebar")?"before":"after")}this.buildmenu(b,l,m,this.ulindex,true,e);m.onmouseover=function(){clearTimeout(FrontColumns_navigation01.ddlevelsmenu.hidetimers[this._master][this._pos])};this.addEvent(m,function(i){if(!FrontColumns_navigation01.ddlevelsmenu.isContained(this,i)&&!FrontColumns_navigation01.ddlevelsmenu.isContained(FrontColumns_navigation01.ddlevelsmenu.topitems[this._master][parseInt(this._pos)],i)){var c=this;if(FrontColumns_navigation01.ddlevelsmenu.enableshim){FrontColumns_navigation01.ddlevelsmenu.hideshim()}FrontColumns_navigation01.ddlevelsmenu.hidetimers[this._master][this._pos]=setTimeout(function(){FrontColumns_navigation01.ddlevelsmenu.hidemenu(c)},FrontColumns_navigation01.ddlevelsmenu.hideinterval)}},"mouseout");var f=m.getElementsByTagName("ul");for(var k=0;k<f.length;k++){this.ulindex++;var a=f[k].parentNode;if(this.arrowpointers.showarrow.sublevel){this.addpointer(a.getElementsByTagName("a")[0],"FrontColumn_navigation01_rightarrowpointer",this.arrowpointers.rightarrow,"before")}this.buildmenu(b,a,f[k],this.ulindex,false,e)}}}this.addEvent(window,function(){FrontColumns_navigation01.ddlevelsmenu.getwindowsize();FrontColumns_navigation01.ddlevelsmenu.gettopitemsdimensions()},"resize")}},d2ddlevelsmenu:{enableshim:false,arrowpointers:{downarrow:["../images/columns/arrow-down.gif",11,7],rightarrow:["../images/columns/nav-arrow-03.gif",7,10],showarrow:{toplevel:false,sublevel:true}},hideinterval:200,effects:{enableswipe:true,enablefade:true,duration:200},httpsiframesrc:"blank.htm",topmenuids:[],topitems:{},subuls:{},lastactivesubul:{},topitemsindex:-1,ulindex:-1,hidetimers:{},shimadded:false,nonFF:!/Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent),getoffset:function(b,a){return(b.offsetParent)?b[a]+this.getoffset(b.offsetParent,a):b[a]},getoffsetof:function(a){a._offsets={left:this.getoffset(a,"offsetLeft"),top:this.getoffset(a,"offsetTop")}},getwindowsize:function(){this.docwidth=window.innerWidth?window.innerWidth-10:this.standardbody.clientWidth-10;this.docheight=window.innerHeight?window.innerHeight-15:this.standardbody.clientHeight-18},gettopitemsdimensions:function(){for(var a=0;a<this.topmenuids.length;a++){var d=this.topmenuids[a];for(var b=0;b<this.topitems[d].length;b++){var e=this.topitems[d][b];var c=document.getElementById(e.getAttribute("rel"));e._dimensions={w:e.offsetWidth,h:e.offsetHeight,submenuw:c.offsetWidth,submenuh:c.offsetHeight}}}},isContained:function(a,b){var b=window.event||b;var d=b.relatedTarget||((b.type=="mouseover")?b.fromElement:b.toElement);while(d&&d!=a){try{d=d.parentNode}catch(b){d=a}}if(d==a){return true}else{return false}},addpointer:function(d,f,a,c){var e=document.createElement("img");e.src=a[0];e.style.width=a[1]+"px";e.style.height=a[2]+"px";if(f=="rightarrowpointer"){e.style.left=d.offsetWidth-a[2]-2+"px"}e.className=f;var b=d.childNodes[d.firstChild.nodeType!=1?1:0];if(b&&b.tagName=="SPAN"){d=b}if(c=="before"){d.insertBefore(e,d.firstChild)}else{d.appendChild(e)}},css:function(b,a,c){var d=new RegExp("(^|\\s+)"+a+"($|\\s+)","ig");if(c=="check"){return d.test(b.className)}else{if(c=="remove"){b.className=b.className.replace(d,"")}else{if(c=="add"&&!d.test(b.className)){b.className+=" "+a}}}},addshimmy:function(b){var c=(!window.opera)?document.createElement("iframe"):document.createElement("div");c.className="ddiframeshim";c.setAttribute("src",location.protocol=="https:"?this.httpsiframesrc:"about:blank");c.setAttribute("frameborder","0");b.appendChild(c);try{c.style.filter="progid:DXImageTransform.Microsoft.Alpha(style=0,opacity=0)"}catch(a){}return c},positionshim:function(g,c,a,f,e){if(g._istoplevel){var e=window.pageYOffset?window.pageYOffset:this.standardbody.scrollTop;var d=g._offsets.top-e;var b=e+this.docheight-g._offsets.top-g._dimensions.h;if(d>0){this.shimmy.topshim.style.left=f+"px";this.shimmy.topshim.style.top=e+"px";this.shimmy.topshim.style.width="99%";this.shimmy.topshim.style.height=d+"px"}if(b>0){this.shimmy.bottomshim.style.left=f+"px";this.shimmy.bottomshim.style.top=g._offsets.top+g._dimensions.h+"px";this.shimmy.bottomshim.style.width="99%";this.shimmy.bottomshim.style.height=b+"px"}}},hideshim:function(){this.shimmy.topshim.style.width=this.shimmy.bottomshim.style.width=0;this.shimmy.topshim.style.height=this.shimmy.bottomshim.style.height=0},buildmenu:function(d,f,c,e,a,b){f._master=d;f._pos=e;f._istoplevel=a;if(a){this.addEvent(f,function(g){FrontColumns_navigation01.d2ddlevelsmenu.hidemenu(FrontColumns_navigation01.d2ddlevelsmenu.subuls[this._master][parseInt(this._pos)])},"click")}this.subuls[d][e]=c;f._dimensions={w:f.offsetWidth,h:f.offsetHeight,submenuw:c.offsetWidth,submenuh:c.offsetHeight};this.getoffsetof(f);c.style.visibility="hidden";this.addEvent(f,function(j){if(!FrontColumns_navigation01.d2ddlevelsmenu.isContained(this,j)){var h=FrontColumns_navigation01.d2ddlevelsmenu.subuls[this._master][parseInt(this._pos)];if(this._istoplevel){FrontColumns_navigation01.d2ddlevelsmenu.css(this,"selected","add");clearTimeout(FrontColumns_navigation01.d2ddlevelsmenu.hidetimers[this._master][this._pos])}FrontColumns_navigation01.d2ddlevelsmenu.getoffsetof(f);var l=window.pageXOffset?window.pageXOffset:FrontColumns_navigation01.d2ddlevelsmenu.standardbody.scrollLeft;var i=window.pageYOffset?window.pageYOffset:FrontColumns_navigation01.d2ddlevelsmenu.standardbody.scrollTop;var n=this._offsets.left+this._dimensions.submenuw+(this._istoplevel&&b=="topbar"?0:this._dimensions.w);var g=this._offsets.top+this._dimensions.submenuh;var m=(this._istoplevel?this._offsets.left+(b=="sidebar"?this._dimensions.w:0):this._dimensions.w);if(n-l>FrontColumns_navigation01.d2ddlevelsmenu.docwidth){m+=-this._dimensions.submenuw+(this._istoplevel&&b=="topbar"?this._dimensions.w:-this._dimensions.w)}h.style.left=m+"px";var k=(this._istoplevel?this._offsets.top+(b=="sidebar"?0:this._dimensions.h):this.offsetTop);if(g-i>FrontColumns_navigation01.d2ddlevelsmenu.docheight){if(this._dimensions.submenuh<this._offsets.top+(b=="sidebar"?this._dimensions.h:0)-i){k+=-this._dimensions.submenuh+(this._istoplevel&&b=="topbar"?-this._dimensions.h:this._dimensions.h)}else{k+=-(this._offsets.top-i)+(this._istoplevel&&b=="topbar"?-this._dimensions.h:0)}}h.style.top=k+"px";if(FrontColumns_navigation01.d2ddlevelsmenu.enableshim&&(FrontColumns_navigation01.d2ddlevelsmenu.effects.enableswipe==false||FrontColumns_navigation01.d2ddlevelsmenu.nonFF)){FrontColumns_navigation01.d2ddlevelsmenu.positionshim(f,h,b,l,i)}else{h.FFscrollInfo={x:l,y:i}}FrontColumns_navigation01.d2ddlevelsmenu.showmenu(f,h,b)}},"mouseover");this.addEvent(f,function(h){var g=FrontColumns_navigation01.d2ddlevelsmenu.subuls[this._master][parseInt(this._pos)];if(this._istoplevel){if(!FrontColumns_navigation01.d2ddlevelsmenu.isContained(this,h)&&!FrontColumns_navigation01.d2ddlevelsmenu.isContained(g,h)){FrontColumns_navigation01.d2ddlevelsmenu.hidemenu(g)}}else{if(!this._istoplevel&&!FrontColumns_navigation01.d2ddlevelsmenu.isContained(this,h)){FrontColumns_navigation01.d2ddlevelsmenu.hidemenu(g)}}},"mouseout")},setopacity:function(a,b){a.style.opacity=b;if(typeof a.style.opacity!="string"){a.style.MozOpacity=b;if(a.filters){a.style.filter="progid:DXImageTransform.Microsoft.alpha(opacity="+b*100+")"}}},showmenu:function(d,b,a){if(this.effects.enableswipe||this.effects.enablefade){if(this.effects.enableswipe){var c=(d._istoplevel&&a=="topbar")?d._dimensions.submenuh:d._dimensions.submenuw;b.style.width=b.style.height=0;b.style.overflow="hidden"}if(this.effects.enablefade){this.setopacity(b,0)}b._curanimatedegree=0;b.style.visibility="visible";clearInterval(b._animatetimer);b._starttime=new Date().getTime();b._animatetimer=setInterval(function(){FrontColumns_navigation01.d2ddlevelsmenu.revealmenu(d,b,c,a)},10)}else{b.style.visibility="visible"}},revealmenu:function(e,c,d,b){var a=new Date().getTime()-c._starttime;if(a<this.effects.duration){if(this.effects.enableswipe){if(c._curanimatedegree==0){c.style[e._istoplevel&&b=="topbar"?"width":"height"]="auto"}c.style[e._istoplevel&&b=="topbar"?"height":"width"]=(c._curanimatedegree*d)+"px"}if(this.effects.enablefade){this.setopacity(c,c._curanimatedegree)}}else{clearInterval(c._animatetimer);if(this.effects.enableswipe){c.style.width="auto";c.style.height="auto";c.style.overflow="visible"}if(this.effects.enablefade){this.setopacity(c,1);c.style.filter=""}if(this.enableshim&&c.FFscrollInfo){this.positionshim(e,c,b,c.FFscrollInfo.x,c.FFscrollInfo.y)}}c._curanimatedegree=(1-Math.cos((a/this.effects.duration)*Math.PI))/2},hidemenu:function(a){if(typeof a._pos!="undefined"){this.css(this.topitems[a._master][parseInt(a._pos)],"selected","remove");if(this.enableshim){this.hideshim()}}clearInterval(a._animatetimer);a.style.visibility="hidden"},addEvent:function(b,c,a){if(b.addEventListener){b.addEventListener(a,c,false)}else{if(b.attachEvent){b.attachEvent("on"+a,function(){return c.call(b,window.event)})}}},init:function(b,e){this.standardbody=(document.compatMode=="CSS1Compat")?document.documentElement:document.body;this.topitemsindex=-1;this.ulindex=-1;this.topmenuids.push(b);this.topitems[b]=[];this.subuls[b]=[];this.hidetimers[b]=[];if(this.enableshim&&!this.shimadded){this.shimmy={};this.shimmy.topshim=this.addshimmy(document.body);this.shimmy.bottomshim=this.addshimmy(document.body);this.shimadded=true}var j=document.getElementById(b);var d=j.getElementsByTagName("a");this.getwindowsize();for(var g=0;g<d.length;g++){if(d[g].getAttribute("rel")){this.topitemsindex++;this.ulindex++;var l=d[g];this.topitems[b][this.topitemsindex]=l;var m=document.getElementById(l.getAttribute("rel"));m.style.zIndex=2000;m._master=b;m._pos=this.topitemsindex;this.addEvent(m,function(){FrontColumns_navigation01.d2ddlevelsmenu.hidemenu(this)},"click");var n=(e=="sidebar")?"rightarrowpointer":"downarrowpointer";var h=(e=="sidebar")?this.arrowpointers.rightarrow:this.arrowpointers.downarrow;if(this.arrowpointers.showarrow.toplevel){this.addpointer(l,n,h,(e=="sidebar")?"before":"after")}this.buildmenu(b,l,m,this.ulindex,true,e);m.onmouseover=function(){clearTimeout(FrontColumns_navigation01.d2ddlevelsmenu.hidetimers[this._master][this._pos])};this.addEvent(m,function(i){if(!FrontColumns_navigation01.d2ddlevelsmenu.isContained(this,i)&&!FrontColumns_navigation01.d2ddlevelsmenu.isContained(FrontColumns_navigation01.d2ddlevelsmenu.topitems[this._master][parseInt(this._pos)],i)){var c=this;if(FrontColumns_navigation01.d2ddlevelsmenu.enableshim){FrontColumns_navigation01.d2ddlevelsmenu.hideshim()}FrontColumns_navigation01.d2ddlevelsmenu.hidetimers[this._master][this._pos]=setTimeout(function(){FrontColumns_navigation01.d2ddlevelsmenu.hidemenu(c)},FrontColumns_navigation01.d2ddlevelsmenu.hideinterval)}},"mouseout");var f=m.getElementsByTagName("ul");for(var k=0;k<f.length;k++){this.ulindex++;var a=f[k].parentNode;if(this.arrowpointers.showarrow.sublevel){this.addpointer(a.getElementsByTagName("a")[0],"rightarrowpointer",this.arrowpointers.rightarrow,"before")}this.buildmenu(b,a,f[k],this.ulindex,false,e)}}}this.addEvent(window,function(){FrontColumns_navigation01.d2ddlevelsmenu.getwindowsize();FrontColumns_navigation01.d2ddlevelsmenu.gettopitemsdimensions()},"resize")}},nativeMenu:function(b){var a;jQuery(document).ready(function(e){a=screen.width;var c=e("#"+b+">ul");var d=c.find("ul").parent();d.each(function(g){var h=e(this);var f=e(this).find("ul:eq(0)");this._dimensions={w:this.offsetWidth,h:this.offsetHeight,subulw:f.outerWidth(),subulh:f.outerHeight()};this.istopheader=h.parents("ul").length==1?true:false;h.hover(function(l){var j=e(this).children("ul:eq(0)");_offsets={left:e(this).offset().left,top:e(this).offset().top};if(e(this).parents("ul").length==1){e(this).attr("class","current")}var m=this.istopheader?0:this._dimensions.w;var k=j.find("li");k.each(function(n){if(e(this).children("ul").length!=0){if(_offsets.left+m+this._dimensions.subulw*2>a){e(this).children("a").attr("class","has-left")}else{e(this).children("a").attr("class","has-right")}}});if(_offsets.left+m+this._dimensions.subulw*2>a){j.addClass(j.parents("ul").length==1||j.parents("ul").attr("class").indexOf("left-slid")!=-1?"left-slid":"left-forward")}e(this).attr("style",j.parents("ul").length==1?"position:relative;z-index:12;":"position:relative;");var i=e(this).children("a").attr("class");if(i!=undefined){if(i.indexOf("left")!=-1){e(this).children("a").addClass(" left-current")}else{if(i.indexOf("right")!=-1){e(this).children("a").addClass(" right-current")}}}e(this).find("ul").attr("style","visibility:visible");e(this).children("ul:eq(0)").find("ul").attr("style","visibility:hidden")},function(i){e(this).children("a").removeClass("right-current");e(this).children("a").removeClass("left-current");e(this).removeClass("current");e(this).find("ul").attr("style","visibility:hidden")})})})}};$(document).ready(function(){var a=null;function b(){if(a){return}a=setInterval(function(){$("#feature li.current a span").animate({top:"-55px"},"fast");$("#feature li.current a p").animate({top:"-55px"},"fast")},200)}function c(){if(!a){return}$("#feature li.current a span").animate({top:"0px"},"fast");$("#feature li.current a p").animate({top:"0px"},"fast");$("#feature li.current").removeClass("current");clearInterval(a);a=null}$("#feature li").hover(function(){$(this).addClass("current");b()},c)});var FrontPublic_slideShow01=function(){this.ce_slide_effect_style=null;this.ce_slide_index=0;this.ce_slide_pic_temple=null;this.ce_slide_open_type=null;this.ce_slide_show_title=null;this.ce_slide_show_content=null;this.ce_slide_tag_style=null;this.ce_slide_recursion_times=null;this.ce_slide_id="";this.ce_requestDataFilePath="";this.ce_slide_settimeout=null;this.ce_slide_autoPlay=null;this.ce_slide_totle=null;this.ce_slide_img_width=null;this.ce_slide_img_height=null;this.ce_slide_thumbnail_width=null;this.ce_slide_thumbnail_height=null;this.ce_slide_tag_text_width=16;this.ce_slide_tag_text_height=16;this.ce_slide_info_mark_height=60;this.ce_slide_thumbnail_max_width=0;this.ce_slide_thumbnail_show_width=0;this.ce_slide_thumbnail_pages=1;this.ce_slide_thumbnail_groups=0;this.ce_slide_thumbnail_tmp=0;this.ce_slide_contes_obj=Object();this.ce_slide_imgs=new Array();this.ce_slide_imgs_hrefs=new Array();this.ce_slide_thumbnails=new Array();this.ce_slide_titles=new Array();this.ce_slide_memos=new Array();this.ce_slide_frame=null;this.ce_slide_contente=null;this.ce_slide_pic=null;this.ce_slide_tag_thumbnail=null;this.ce_slide_thumbnail_list=null;this.ce_slide_thumbnail_arrowhead=null;this.ce_slide_tag_text=null;this.ce_slide_info_mark=null;this.ce_slide_info=null;this.ce_slide_info_title=null;this.ce_slide_text_memo=null;this.ce_slide_arrowhead_left=null;this.ce_slide_arrowhead_right=null;this.FrontPublic_slideShow01_tempSetTimeout=null;this.ce_slide_init=function(setJsonData,querySegment,tempData){window.clearTimeout(this.FrontPublic_slideShow01_tempSetTimeout);if(setJsonData){var setJsonData=this.ce_slide_strToJson(setJsonData);this.ce_slide_open_type=setJsonData.openType;this.ce_slide_tag_style=setJsonData.showType;this.ce_slide_recursion_times=setJsonData.changeTimes;this.ce_slide_show_title=setJsonData.isShowSlideTitle;this.ce_slide_show_content=setJsonData.isShowSlideContent;this.ce_requestDataFilePath=setJsonData.requestDataFilePath;this.ce_slide_id=this.ce_requestDataFilePath.replace("/comp-FrontSlide_listJson01","FrontPublic_slideShow01");var d=new Date();var t=""+d.getFullYear()+d.getMonth()+d.getDate();this.ce_slide_contes_obj=tempData;this.ce_slide_frame=$("#"+this.ce_slide_id+"");this.ce_slide_contente=$("#"+this.ce_slide_id+" .slide-contente");this.ce_slide_pic=$("#"+this.ce_slide_id+" .slide-pic ul");this.ce_slide_tag_thumbnail=$("#"+this.ce_slide_id+" .slide-tag-thumbnail ul");this.ce_slide_thumbnail_list=$("#"+this.ce_slide_id+" .thumbnail-list");this.ce_slide_thumbnail_arrowhead=$("#"+this.ce_slide_id+" .slide-tag-thumbnail .arrowhead");this.ce_slide_tag_text=$("#"+this.ce_slide_id+" .slide-tag-text ul");this.ce_slide_info_mark=$("#"+this.ce_slide_id+" .slide-info-mark");this.ce_slide_info=$("#"+this.ce_slide_id+" .slide-info");this.ce_slide_info_title=$("#"+this.ce_slide_id+" .slide-info h3");this.ce_slide_text_memo=$("#"+this.ce_slide_id+" .slide-text");this.ce_slide_arrowhead_left=$("#"+this.ce_slide_id+" .arrowhead-left");this.ce_slide_arrowhead_right=$("#"+this.ce_slide_id+" .arrowhead-right");this.ce_slide_totle=this.ce_slide_contes_obj.contents.length;this.ce_slide_contents_init();this.ce_slide_tag_init();this.ce_slide_img_init();this.ce_slide_run();var thise=this;this.ce_slide_pic.hover(function(event){window.clearTimeout(thise.FrontPublic_slideShow01_tempSetTimeout)},function(event){thise.ce_slide_loop()})}};this.ce_slide_contents_init=function(){this.ce_slide_effect_style=this.ce_slide_contes_obj.setData.changeStyle;this.ce_slide_autoPlay=this.ce_slide_contes_obj.setData.isPlaysSet;for(var i=0;i<this.ce_slide_totle;i++){this.ce_slide_imgs[i]=this.ce_slide_contes_obj.contents[i].bigPicPath;this.ce_slide_imgs[i]=this.ce_slide_contes_obj.contents[i].bigPicPath;this.ce_slide_imgs_hrefs[i]=this.ce_slide_contes_obj.contents[i].plink;this.ce_slide_thumbnails[i]=this.ce_slide_contes_obj.contents[i].smallPicPath;this.ce_slide_titles[i]=this.ce_slide_contes_obj.contents[i].slideName;this.ce_slide_memos[i]=this.ce_slide_contes_obj.contents[i].descriPtion}};this.ce_slide_tag_text_init=function(){for(var i=0;i<this.ce_slide_totle;i++){if(i==0){this.ce_slide_tag_text.append("<li class='slide-hover'>"+(i+1)+"</li>")}else{this.ce_slide_tag_text.append("<li>"+(i+1)+"</li>")}}};this.ce_slide_tag_thumbnail_init=function(){if(this.ce_slide_thumbnails.length){for(var i=0;i<this.ce_slide_totle;i++){this.ce_slide_tag_thumbnail.append("<li><img src='"+this.ce_slide_thumbnails[i]+"' /></li>")}}this.ce_slide_thumbnail_max_width+=parseInt(this.ce_slide_tag_thumbnail.find("li").width());this.ce_slide_thumbnail_max_width+=parseInt(this.ce_slide_tag_thumbnail.find("li").css("margin-left").replace("px",""));this.ce_slide_thumbnail_max_width+=parseInt(this.ce_slide_tag_thumbnail.find("li").css("margin-right").replace("px",""));this.ce_slide_thumbnail_max_width+=parseInt(this.ce_slide_tag_thumbnail.find("li").css("padding-left").replace("px",""));this.ce_slide_thumbnail_max_width+=parseInt(this.ce_slide_tag_thumbnail.find("li").css("padding-right").replace("px",""));this.ce_slide_thumbnail_max_width=parseInt(this.ce_slide_thumbnail_max_width*this.ce_slide_totle);if(parseInt(this.ce_slide_frame.width())<this.ce_slide_thumbnail_max_width){this.ce_slide_thumbnail_show_width=this.ce_slide_frame.width()-parseInt(this.ce_slide_tag_thumbnail.parent().parent().find(".arrowhead").width()*2);this.ce_slide_tag_thumbnail.parent().width(this.ce_slide_thumbnail_show_width);this.ce_slide_tag_thumbnail.width(this.ce_slide_thumbnail_max_width);this.ce_slide_thumbnail_groups=this.ce_slide_thumbnail_max_width/this.ce_slide_thumbnail_show_width;this.ce_slide_thumbnail_groups=(Math.floor(this.ce_slide_thumbnail_groups)>0)?parseInt(this.ce_slide_thumbnail_groups)+1:this.ce_slide_thumbnail_groups;this.ce_slide_arrowhead_left.addClass("no-arrowhead")}else{var li_width=parseInt(this.ce_slide_frame.width())/parseInt(this.ce_slide_totle);li_width=li_width/parseInt(this.ce_slide_frame.width())*100;this.ce_slide_tag_thumbnail.find("li").attr("style","padding:0px;margin:0px;width:"+li_width+"%");this.ce_slide_tag_thumbnail.width(parseInt(this.ce_slide_frame.width()));this.ce_slide_tag_thumbnail.parent().width(parseInt(this.ce_slide_frame.width()));this.ce_slide_thumbnail_arrowhead.attr("style","display:none")}};this.ce_slide_tag_init=function(){switch(parseInt(this.ce_slide_tag_style)){case 1:this.ce_slide_tag_text.parent().css("display","block");this.ce_slide_tag_text_init();break;case 0:this.ce_slide_tag_thumbnail.parent().parent().css("display","block");this.ce_slide_tag_thumbnail_init();break}};this.ce_slide_tag_changeStyle=function(){var nowObj=null;if(this.ce_slide_tag_text.length){this.ce_slide_tag_text.find("li").removeClass();nowObj=this.ce_slide_tag_text.find("li:eq("+this.ce_slide_index+")");nowObj.addClass("slide-hover")}if(this.ce_slide_thumbnails.length){this.ce_slide_tag_thumbnail.find("li").removeClass();nowObj=this.ce_slide_tag_thumbnail.find("li:eq("+this.ce_slide_index+")");nowObj.addClass("slide-hover")}};this.ce_slide_img_init=function(){this.ce_slide_pic.html("");this.ce_slide_contente.css("height",this.ce_slide_img_height);for(var i=0;i<this.ce_slide_totle;i++){if(parseInt(this.ce_slide_imgs_hrefs[i].length)>0){this.ce_slide_pic.append("<li><a href='"+this.ce_slide_imgs_hrefs[i]+"' target='"+this.ce_slide_open_type+"'><img src='"+this.ce_slide_imgs[i]+"' /></a></li>")}else{if(parseInt(this.ce_slide_imgs_hrefs[i].length)<=0){this.ce_slide_pic.append("<li><img src='"+this.ce_slide_imgs[i]+"' /></li>")}}}};this.ce_slide_effect_init=function(style){switch(style){case 1:if(!this.ce_slide_pic_temple){this.ce_slide_pic_temple=this.ce_slide_pic.find("li:eq("+(this.ce_slide_imgs.length-1)+")")}this.ce_slide_effect_gradual();break;case 2:this.ce_slide_pic_temple=(this.ce_slide_pic_temple)?this.ce_slide_pic_temple:1;this.ce_slide_pic_temple=(this.ce_slide_index==null)?this.ce_slide_pic_temple:(this.ce_slide_index+1);this.ce_slide_effect_aspect_x("right");break;case 3:this.ce_slide_pic_temple=(this.ce_slide_pic_temple)?this.ce_slide_pic_temple:1;this.ce_slide_pic_temple=(this.ce_slide_index==null)?this.ce_slide_pic_temple:(this.ce_slide_index+1);this.ce_slide_effect_aspect_x("left");break;case 4:this.ce_slide_pic_temple=(this.ce_slide_pic_temple)?this.ce_slide_pic_temple:1;this.ce_slide_pic_temple=(this.ce_slide_index==null)?this.ce_slide_pic_temple:(this.ce_slide_index+1);this.ce_slide_effect_aspect_y("bottom");break;case 5:this.ce_slide_pic_temple=(this.ce_slide_pic_temple)?this.ce_slide_pic_temple:1;this.ce_slide_pic_temple=(this.ce_slide_index==null)?this.ce_slide_pic_temple:(this.ce_slide_index+1);this.ce_slide_effect_aspect_y("top");break}};this.ce_slide_effect_aspect_x=function(aspect){var aspect_float;var slide_pic_width=this.ce_slide_frame.width()*this.ce_slide_imgs.length;var now_position;if(aspect=="left"){aspect_float="right";now_position=-(slide_pic_width-this.ce_slide_frame.width()*this.ce_slide_pic_temple)}if(aspect=="right"){aspect_float="left";now_position=(this.ce_slide_pic_temple==1)?0:-(this.ce_slide_frame.width()*(this.ce_slide_pic_temple-1))}this.ce_slide_pic.css("position","absolute");this.ce_slide_pic.css("width",slide_pic_width);this.ce_slide_pic.animate({left:now_position},"slow");this.ce_slide_pic.find("li").css("float",aspect_float);this.ce_slide_pic_temple=(this.ce_slide_pic_temple>=this.ce_slide_imgs.length)?1:this.ce_slide_pic_temple+1};this.ce_slide_effect_aspect_y=function(aspect){if(aspect=="top"){this.ce_slide_pic.html("");this.ce_slide_pic.css("position","absolute");for(var i=this.ce_slide_imgs.length-1;i>=0;i--){if(parseInt(this.ce_slide_imgs_hrefs[i].length)){this.ce_slide_pic.append("<li><a href='"+this.ce_slide_imgs_hrefs[i]+"'><img src='"+this.ce_slide_imgs[i]+"' /></a></li>")}else{this.ce_slide_pic.append("<li><img src='"+this.ce_slide_imgs[i]+"' /></li>")}}var now_position=-(this.ce_slide_pic.height()-this.ce_slide_pic.find("li").height()*this.ce_slide_pic_temple);this.ce_slide_pic.animate({top:now_position},"slow")}if(aspect=="bottom"){this.ce_slide_pic.css("position","absolute");var now_position=(this.ce_slide_pic_temple==1)?0:-(this.ce_slide_pic.find("li").height()*(this.ce_slide_pic_temple-1));this.ce_slide_pic.animate({top:now_position},"slow")}this.ce_slide_pic_temple=(this.ce_slide_pic_temple>=this.ce_slide_imgs.length)?1:this.ce_slide_pic_temple+1};this.ce_slide_effect_gradual=function(){this.ce_slide_pic.find("li").css("position","absolute");this.ce_slide_pic.find("li").css("top","0");this.ce_slide_pic.find("li").css("left","0");this.ce_slide_pic.find("li").css("display","none");var nowOBJ=this.ce_slide_pic.find("li:eq("+this.ce_slide_index+")");nowOBJ.fadeIn("slow")};this.ce_slide_show=function(){this.ce_slide_effect_init(this.ce_slide_effect_style);this.ce_slide_contente.width(this.ce_slide_frame.width());this.ce_slide_pic.find("img").width(this.ce_slide_frame.width());this.ce_slide_pic.find("img").height(this.ce_slide_contente.height());this.ce_slide_pic.parent().width(this.ce_slide_frame.width());this.ce_slide_info_title.html("");this.ce_slide_text_memo.html("");this.ce_slide_tag_changeStyle();if(parseInt(this.ce_slide_show_title)){this.ce_slide_info_title.html(this.ce_slide_titles[this.ce_slide_index])}if(parseInt(this.ce_slide_show_content)){this.ce_slide_text_memo.html(this.ce_slide_memos[this.ce_slide_index])}this.ce_slide_index=(this.ce_slide_index>=(this.ce_slide_imgs.length-1))?0:(this.ce_slide_index+1)};this.ce_slide_loop=function(){this.ce_slide_show();var thise=this;if(this.ce_slide_autoPlay){thise.FrontPublic_slideShow01_tempSetTimeout=setTimeout(function(){thise.ce_slide_loop()},thise.ce_slide_recursion_times)}};this.ce_slide_hover_init=function(obj,thise){obj.click(function(){thise.ce_slide_index=obj.index(this);thise.ce_slide_show();if(this.ce_slide_autoPlay){window.clearTimeout(thise.FrontPublic_slideShow01_tempSetTimeout);thise=setTimeout(function(){thise.ce_slide_loop()},thise.ce_slide_recursion_times)}})};this.ce_slide_arrowhead_click_init=function(obj,thise){obj.click(function(){var arrowhead=$(this).attr("class").split(" ");switch(arrowhead[0].replace(/(^\s*)|(\s*$)/g,"")){case"arrowhead-left":if(thise.ce_slide_thumbnail_pages>1&&thise.ce_slide_thumbnail_pages!=1){thise.ce_slide_thumbnail_tmp+=thise.ce_slide_thumbnail_show_width;thise.ce_slide_tag_thumbnail.animate({left:thise.ce_slide_thumbnail_tmp},"slow");thise.ce_slide_thumbnail_pages=((thise.ce_slide_thumbnail_pages-1)<0)?0:(thise.ce_slide_thumbnail_pages-1)}if(thise.ce_slide_thumbnail_pages<=1){$(this).addClass("no-arrowhead");thise.ce_slide_arrowhead_right.removeClass("no-arrowhead")}if(thise.ce_slide_thumbnail_pages<thise.ce_slide_thumbnail_groups){thise.ce_slide_arrowhead_right.removeClass("no-arrowhead")}break;case"arrowhead-right":if(thise.ce_slide_thumbnail_pages<thise.ce_slide_thumbnail_groups){thise.ce_slide_thumbnail_tmp-=thise.ce_slide_thumbnail_show_width;thise.ce_slide_tag_thumbnail.animate({left:thise.ce_slide_thumbnail_tmp},"slow");thise.ce_slide_thumbnail_pages+=1}if(thise.ce_slide_thumbnail_pages>=thise.ce_slide_thumbnail_groups){$(this).addClass("no-arrowhead");thise.ce_slide_arrowhead_left.removeClass("no-arrowhead")}if(thise.ce_slide_thumbnail_pages>1&&thise.ce_slide_thumbnail_pages!=1){thise.ce_slide_arrowhead_left.removeClass("no-arrowhead")}break}})};this.ce_slide_run=function(){var arrowhead_h;this.ce_slide_hover_init(this.ce_slide_tag_thumbnail.find("li"),this);this.ce_slide_hover_init(this.ce_slide_tag_text.find("li"),this);this.ce_slide_arrowhead_click_init(this.ce_slide_tag_thumbnail.parent().parent().find(".arrowhead"),this);var thise=this;this.ce_slide_tag_thumbnail.parent().parent().find(".arrowhead").hover(function(){arrowhead_h=$(this).attr("class").split(" ");switch(arrowhead_h[0].replace(/(^\s*)|(\s*$)/g,"")){case"arrowhead-left":if(thise.ce_slide_thumbnail_pages>1){$(this).addClass("arrowhead-left-hover")}break;case"arrowhead-right":if(thise.ce_slide_thumbnail_pages<thise.ce_slide_thumbnail_groups){$(this).addClass("arrowhead-right-hover")}break}},function(){arrowhead_h=$(this).attr("class").split(" ");switch(arrowhead_h[0].replace(/(^\s*)|(\s*$)/g,"")){case"arrowhead-left":$(this).removeClass("arrowhead-left-hover");break;case"arrowhead-right":$(this).removeClass("arrowhead-right-hover");break}});this.ce_slide_loop()};this.d5_slide=function(userW,userH){var sWidth=$("#slider_name").width();$("#slider_name").width(userW);$("#slider_name").height(userH);var len=$("#slider_name .silder_panel").length;var index=0;var picTimer;var btn="<a class='prev'>Prev</a><a class='next'>Next</a>";$("#slider_name").append(btn);$("#slider_name .silder_nav li").css({opacity:"0.6",filter:"alpha(opacity=60)"}).mouseover(function(){index=$("#slider_name .silder_nav li").index(this);showPics(index)}).eq(0).trigger("mouseover");$("#slider_name .prev,#slider_name .next").css({opacity:"0.2",filter:"alpha(opacity=20)"}).hover(function(){$(this).stop(true,false).animate({opacity:"0.6",filter:"alpha(opacity=60)"},300)},function(){$(this).stop(true,false).animate({opacity:"0.2",filter:"alpha(opacity=20)"},300)});$("#slider_name .prev").click(function(){index-=1;if(index==-1){index=len-1}showPics(index)});$("#slider_name .next").click(function(){index+=1;if(index==len){index=0}showPics(index)});$("#slider_name .silder_con").css("width",sWidth*(len));$("#slider_name").hover(function(){clearInterval(picTimer)},function(){picTimer=setInterval(function(){showPics(index);index++;if(index==len){index=0}},3000)}).trigger("mouseleave");function showPics(index){var nowLeft=-index*sWidth;$("#slider_name .silder_con").stop(true,false).animate({left:nowLeft},300);$("#slider_name .silder_nav li").removeClass("current").eq(index).addClass("current");$("#slider_name .silder_nav li").stop(true,false).animate({opacity:"0.5"},300).eq(index).stop(true,false).animate({opacity:"1"},300)}};this.ce_slide_strToJson=function(str){segs=str.match(/=/g).length;for(var i=0;i<segs;i++){str=str.replace("=",":'").replace("&","',")}str+="'";return eval("str = {"+str+"};")}};var FrontPublic_slideShow02=function(){function c(f,d,h){var j=f.getElementsByTagName(d);for(var g=0,k=j.length,e=[];g<k;g++){if(j[g].className==h){e.push(j[g])}}if(e.length==1){e=e[0]}return e}function a(d,e){if(d.filters){d.filters.alpha.opacity=Math.round(e)}else{d.style.opacity=e/100}}function b(e,h,d,g,j){this.slides=[];this.over=false;this.S=this.S0=h;this.iW=d;this.iH=g;this.oP=j;this.oc=document.getElementById(e);this.frm=c(this.oc,"div","slide");this.NF=this.frm.length;this.resize();for(var f=0;f<this.NF;f++){this.slides[f]=new Slide(this,f)}this.oc.parent=this;this.view=this.slides[0];this.Z=this.mx;this.oc.onmouseout=function(){this.parent.mouseout();return false}}b.prototype={run:function(){this.Z+=this.over?(this.mn-this.Z)*0.5:(this.mx-this.Z)*0.5;this.view.calc();var d=this.NF;while(d--){this.slides[d].move()}},resize:function(){this.wh=this.oc.clientWidth;this.ht=this.oc.clientHeight;this.wr=this.wh*this.iW;this.r=this.ht/this.wr;this.mx=this.wh/this.NF;this.mn=(this.wh*(1-this.iW))/(this.NF-1)},mouseout:function(){this.over=false;a(this.view.img,this.oP)}};Slide=function(d,e){this.parent=d;this.N=e;this.x0=this.x1=e*d.mx;this.v=0;this.loaded=false;this.cpt=0;this.start=new Date();this.obj=d.frm[e];this.img=c(this.obj,"img","diapo");if(e==0){this.obj.style.borderLeft="none"}this.obj.style.left=Math.floor(this.x0)+"px";a(this.img,d.oP);this.obj.parent=this;this.obj.onmouseover=function(){this.parent.over();return false}};Slide.prototype={calc:function(){var e=this.parent;for(var d=0;d<=this.N;d++){e.slides[d].x1=d*e.Z}for(var d=this.N+1;d<e.NF;d++){e.slides[d].x1=e.wh-(e.NF-d)*e.Z}},move:function(){var f=this.parent;var e=(this.x1-this.x0)/f.S;if(this.N&&Math.abs(e)>0.5){this.obj.style.left=Math.floor(this.x0+=e)+"px"}var d=(this.N<f.NF-1)?f.slides[this.N+1].x0-this.x0:f.wh-this.x0;if(Math.abs(d-this.v)>0.5){this.v=d;this.cpt++}else{if(!this.pro){this.pro=true;var g=new Date()-this.start;if(this.cpt>1){f.S=Math.max(2,(28/(g/this.cpt))*f.S0)}}}if(!this.loaded){if(this.img.complete){this.img.style.visibility="visible";this.loaded=true}}},over:function(){this.parent.resize();this.parent.over=true;a(this.parent.view.img,this.parent.oP);this.parent.view=this;this.start=new Date();this.cpt=0;this.pro=false;this.calc();a(this.img,100)}};return{init:function(d){this.s1=new b("slider",d,1.84/3,1/3.2,70);setInterval("FrontPublic_slideShow02.s1.run();",d)}}}();var FrontMessages_customizeEmit01={
	/**
	 * 截取电话字符串。
	 *
	 * @param s 
	 * @return
	 */
	isValidPhone:function(s) {
		if (!/^[\d\-()、]{7,32}$/.test(s)) return false;
		var stack = [];
		for (var i=0,c; c=s.charAt(i); i++) {
			if (c == '(') {
				stack.push(c);
			} else if (c == ')') {
				if (stack.pop() != '(') return false;
			}
		}
		return !stack.length;
	},
	isIdCard:function (str)    
	{   
	    var patrn = /^\s*\d{15}\s*$/;   
	    var patrn1 = /^\s*\d{16}[\dxX]{2}\s*$/;   
	    if(!patrn.exec(str) && !patrn1.exec(str))   
	    {   
	        return false;   
	    }    
	    return true;   
	} 
	,
	/**
	 * 显示相应的提示信息。
	 *
	 * @param data 已经填写好的表单的数据
	 * @return
	 */

	displayInfo:function(disInfo){
		document.getElementById(disInfo).style.display="block";
		//$("#"+disInfo).css({display:"block"});
	},
	/**
	 * 隐藏相应的提示信息。
	 *
	 * @param data 已经填写好的表单的数据
	 * @return
	 */
	
	hideInfo:function(hideInfo){ 	
		document.getElementById(hideInfo).style.display="none";
		//$("#"+hideInfo).css({display:"none"});
	},
	/**
	 * 显示相应的提示信息。
	 *
	 * @param flag 
	 * @return
	 */
	showinfo:function(flag){
		strarr=flag.split("_")
		laststr=strarr[strarr.length-1];
		strinfo="";
		strno="";
		strerr="";
		strpast="";
		for(i=0;i<strarr.length-1;i++){
			if(i==0){
				strinfo=strinfo+strarr[i];
				strno=strno+strarr[i];
				strerr=strerr+strarr[i];
				strpast=strpast+strarr[i];
			}else{
				strinfo=strinfo+"_"+strarr[i];
				strno=strno+"_"+strarr[i];
				strerr=strerr+"_"+strarr[i];
				strpast=strpast+"_"+strarr[i];
			}
		}
		strinfor=strinfo+"_info"+laststr
		strinfo_black=strinfo+"_info"+laststr+"_black";
		strno=strno+"_no"+laststr;
		strerr=strerr+"_err"+laststr;
		strpast=strpast+"_past"+laststr;
		if(document.getElementById(strinfor))
		{document.getElementById(strinfor).style.display="none";}
		if(document.getElementById(strno))
		{document.getElementById(strno).style.display="none";}
		if(document.getElementById(strerr))
		{document.getElementById(strerr).style.display="none";}
		if(document.getElementById(strinfo_black))
		{document.getElementById(strinfo_black).style.display="block";}
		if(document.getElementById(strpast))
		{document.getElementById(strpast).style.display="none";}
		//$("span[@flag="+flag+"w]").css({display:"none"});
		//$("span[@flag="+flag+"r]").css({display:"none"});
		//$("span[@flag="+flag+"m]").css({display:"block"});
	},
	/**
	 * 表单验证
	 *
	 * @param form 页面提交的表单
	 * @return
	 */
    checkForm:function(form,item,compid,attributeType,attributeConstraint){
    
    
    	var subitem=item;
    	var isSub=true;
    	//验证邮件
    	if((item=="all"||item=="mail")&&form.mail){
    		form.mail.value = form.mail.value.replace(/^\s+|\s+$/g, "");
    		//如果后台选择必填，或前台勾选邮件联系，那么邮件为必填，且必须正确
    		if(form.isByMail||form.isDisplayMail.value=='1'){
	    		if(form.isDisplayMail.value=='1'||form.isByMail.checked){
	    		    if(!isEmail(form.mail.value)){
						FrontMessages_customizeEmit01.hideInfo(compid+"_infomail");
						FrontMessages_customizeEmit01.hideInfo(compid+"_infomail_black");
				 		FrontMessages_customizeEmit01.hideInfo(compid+"_nomail");
						FrontMessages_customizeEmit01.displayInfo(compid+"_errmail");
						isSub=false;
					}
				 	if (/^\s*$/.test(form.mail.value)) {
				 		FrontMessages_customizeEmit01.hideInfo(compid+"_infomail");
				 		FrontMessages_customizeEmit01.hideInfo(compid+"_infomail_black");
				 		FrontMessages_customizeEmit01.hideInfo(compid+"_errmail");
						FrontMessages_customizeEmit01.displayInfo(compid+"_nomail");
						isSub=false;
				 	}
		    	}
	    	}
	    	if(form.isDisplayMail.value=='0'){
	    	  	if(!isEmail(form.mail.value)&&!/^\s*$/.test(form.mail.value)){
					FrontMessages_customizeEmit01.hideInfo(compid+"_infomail");
					FrontMessages_customizeEmit01.hideInfo(compid+"_infomail_black");
			 		FrontMessages_customizeEmit01.hideInfo(compid+"_nomail");
					FrontMessages_customizeEmit01.displayInfo(compid+"_errmail");
					isSub=false;
				}
	    	}
			if(isSub==true){
				FrontMessages_customizeEmit01.hideInfo(compid+"_infomail_black");
				FrontMessages_customizeEmit01.displayInfo(compid+"_infomail");
			}
		}
		if((item=="all"||item=="author")&&form.author){
		 	form.author.value = form.author.value.replace(/^\s+|\s+$/g, "");
			 	if(specialCharactersCheck(form.author.value)){
			 	    FrontMessages_customizeEmit01.hideInfo(compid+"_infoauthor");
			 	    FrontMessages_customizeEmit01.hideInfo(compid+"_infoauthor_black");
			 		FrontMessages_customizeEmit01.hideInfo(compid+"_noauthor");
					FrontMessages_customizeEmit01.displayInfo(compid+"_errauthor");
					isSub=false;
			 	}
		 	
		 	if(form.isDisplayAuthor.value=='1'){
			 	if (/^\s*$/.test(form.author.value)) {
					FrontMessages_customizeEmit01.hideInfo(compid+"_infoauthor");
					FrontMessages_customizeEmit01.hideInfo(compid+"_infoauthor_black");
			 		FrontMessages_customizeEmit01.hideInfo(compid+"_errauthor");
					FrontMessages_customizeEmit01.displayInfo(compid+"_noauthor");
					isSub=false;
			 	}
		 	}
		 	if(isSub==true){
				FrontMessages_customizeEmit01.hideInfo(compid+"_infoauthor_black");
				FrontMessages_customizeEmit01.displayInfo(compid+"_infoauthor");
			}
	    }
	    //手机验证
	    if((item=="all"||item=="mobile")&&form.mobile){
	    	form.mobile.value = form.mobile.value.replace(/^\s+|\s+$/g, "");
	    	var mobile =  trim(form.mobile.value);
	    	if(form.isByNote||form.isDisplayMobile.value=='1'){
		    	if(form.isDisplayMobile.value=='1'||form.isByNote.checked){
			    	if (/^\s*$/.test(form.mobile.value)) {
						FrontMessages_customizeEmit01.hideInfo(compid+"_infomobile");
						FrontMessages_customizeEmit01.hideInfo(compid+"_infomobile_black");
				 		FrontMessages_customizeEmit01.hideInfo(compid+"_errmobile");
						FrontMessages_customizeEmit01.displayInfo(compid+"_nomobile");
						isSub=false;
				 	}else if(!isMobileNumber(mobile)||!(/^1[3|4|5|7|8]\d{9}$/.test(form.mobile.value))){
						FrontMessages_customizeEmit01.hideInfo(compid+"_infomobile");
						FrontMessages_customizeEmit01.hideInfo(compid+"_infomobile_black");
				 		FrontMessages_customizeEmit01.hideInfo(compid+"_nomobile");
						FrontMessages_customizeEmit01.displayInfo(compid+"_errmobile");
						isSub=false;
					}
				}
			}
			if(form.isDisplayMobile.value=='0'){
				if (!/^\s*$/.test(form.mobile.value)) {
					if(!isMobileNumber(mobile)||!(/^1[3|4|5|7|8]\d{9}$/.test(form.mobile.value))){
						FrontMessages_customizeEmit01.hideInfo(compid+"_infomobile");
						FrontMessages_customizeEmit01.hideInfo(compid+"_infomobile_black");
				 		FrontMessages_customizeEmit01.hideInfo(compid+"_nomobile");
						FrontMessages_customizeEmit01.displayInfo(compid+"_errmobile");
						isSub=false;
					}
				}
			}
		
			if(isSub==true){
				FrontMessages_customizeEmit01.hideInfo(compid+"_infomobile_black");
				FrontMessages_customizeEmit01.displayInfo(compid+"_infomobile");
			}
	    }
	    
	    if((item=="all"||item=="phone")&&form.phone){
	    	form.phone.value = form.phone.value.replace(/^\s+|\s+$/g, "");
	    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
		    	if (!/^\s*$/.test(form.phone.value)) {
			    	if (!FrontMessages_customizeEmit01.isValidPhone(form.phone.value)) {
			    		FrontMessages_customizeEmit01.hideInfo(compid+"_infophone");
			    		FrontMessages_customizeEmit01.hideInfo(compid+"_infophone_black");
				 		FrontMessages_customizeEmit01.hideInfo(compid+"_nophone");
						FrontMessages_customizeEmit01.displayInfo(compid+"_errphone");
						isSub=false;
			    	}
	    		}
	    	if(form.isDisplayPhone.value=='1'){
		    	if (/^\s*$/.test(form.phone.value)) {
		    		FrontMessages_customizeEmit01.hideInfo(compid+"_infophone");
		    		FrontMessages_customizeEmit01.hideInfo(compid+"_infophone_black");
			 		FrontMessages_customizeEmit01.hideInfo(compid+"_errphone");
					FrontMessages_customizeEmit01.displayInfo(compid+"_nophone");
					isSub=false;
		    	}
	    	}
			if(isSub==true){
				FrontMessages_customizeEmit01.hideInfo(compid+"_infophone_black");
				FrontMessages_customizeEmit01.displayInfo(compid+"_infophone");
			}
	    }

	   /* if((item=="all"||item=="address")&&form.address){  
			form.address.value = form.address.value.replace(/^\s+|\s+$/g, "");
			if(form.isDisplayAddress.value=='1'){
				if (/^\s*$/.test(form.address.value)) {
		    		FrontMessages_customizeEmit01.displayInfo(compid+"_noaddress");
					isSub=false;
				}
			}
		}*/
        if((item=="all"||item=="address")&&form.address){  
			form.address.value = form.address.value.replace(/^\s+|\s+$/g, "");
			//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
				   	if (!/^\s*$/.test(form.address.value)) {
				    	if(specialCharactersCheck(form.address.value)){
				    		FrontMessages_customizeEmit01.hideInfo(compid+"_infoaddress");
				    		FrontMessages_customizeEmit01.hideInfo(compid+"_infoaddress_black");
					 		FrontMessages_customizeEmit01.hideInfo(compid+"_noaddress");
							FrontMessages_customizeEmit01.displayInfo(compid+"_erraddress");
							isSub=false;
				    	}
		    		}
			if(form.isDisplayAddress.value=='1'){
				if (/^\s*$/.test(form.address.value)) {
		    		FrontMessages_customizeEmit01.hideInfo(compid+"_infoaddress");
		    		FrontMessages_customizeEmit01.hideInfo(compid+"_infoaddress_black");
			 		FrontMessages_customizeEmit01.hideInfo(compid+"_noaddress");
		    		FrontMessages_customizeEmit01.displayInfo(compid+"_noaddress");
					isSub=false;
				}
			}
			if(isSub==true){
				FrontMessages_customizeEmit01.hideInfo(compid+"_infoaddress_black");
				FrontMessages_customizeEmit01.displayInfo(compid+"_infoaddress");
			    }
		}
		/*if((item=="all"||item=="area")&&form.area){
			form.area.value = form.area.value.replace(/^\s+|\s+$/g, "");
			if(form.isDisplayArea.value=='1'){
				if (/^\s*$/.test(form.area.value)) {
					FrontMessages_customizeEmit01.displayInfo(compid+"_noarea");
					isSub=false;
				}
			}
		}*/
		if((item=="all"||item=="area")&&form.area){
			form.area.value = form.area.value.replace(/^\s+|\s+$/g, "");
			     //首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
				   	if (!/^\s*$/.test(form.area.value)) {
				    	if(specialCharactersCheck(form.area.value)){
				    		FrontMessages_customizeEmit01.hideInfo(compid+"_infoarea");
				    		FrontMessages_customizeEmit01.hideInfo(compid+"_infoarea_black");
					 		FrontMessages_customizeEmit01.hideInfo(compid+"_noarea");
							FrontMessages_customizeEmit01.displayInfo(compid+"_errarea");
							isSub=false;
				    	}
		    		}
			
					if(form.isDisplayArea.value=='1'){
						if (/^\s*$/.test(form.area.value)) {
						    FrontMessages_customizeEmit01.hideInfo(compid+"_infoarea");
				    		FrontMessages_customizeEmit01.hideInfo(compid+"_infoarea_black");
					 		FrontMessages_customizeEmit01.hideInfo(compid+"_noarea");
							FrontMessages_customizeEmit01.displayInfo(compid+"_noarea");
							isSub=false;
						}
					}
					if(isSub==true){
					FrontMessages_customizeEmit01.hideInfo(compid+"_infoarea_black");
					FrontMessages_customizeEmit01.displayInfo(compid+"_infoarea");
				    }
		}
		/*if((item=="all"||item=="corpName")&&form.corpName){
			form.corpName.value = form.corpName.value.replace(/^\s+|\s+$/g, "");
			if(form.isDisplayCorpName.value=='1'){
				if (/^\s*$/.test(form.corpName.value)) {
					FrontMessages_customizeEmit01.displayInfo(compid+"_nocorpName");
					isSub=false;
				}
			}
		}	*/
		  if((item=="all"||item=="corpName")&&form.corpName){
				form.corpName.value = form.corpName.value.replace(/^\s+|\s+$/g, "");
			               //首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
				   	if (!/^\s*$/.test(form.corpName.value)) {
				    	if(specialCharactersCheck(form.corpName.value)){
				    		FrontMessages_customizeEmit01.hideInfo(compid+"_infocorpName");
				    		FrontMessages_customizeEmit01.hideInfo(compid+"_infocorpName_black");
					 		FrontMessages_customizeEmit01.hideInfo(compid+"_nocorpName");
							FrontMessages_customizeEmit01.displayInfo(compid+"_errcorpName");
							isSub=false;
				    	}
		    		}
		    		
				if(form.isDisplayCorpName.value=='1'){
					if (/^\s*$/.test(form.corpName.value)) {
						FrontMessages_customizeEmit01.hideInfo(compid+"_infocorpName");
			    		FrontMessages_customizeEmit01.hideInfo(compid+"_infocorpName_black");
				 		FrontMessages_customizeEmit01.hideInfo(compid+"_errcorpName");
						FrontMessages_customizeEmit01.displayInfo(compid+"_nocorpName");
						isSub=false;
					}
				}
	            if(isSub==true){
					FrontMessages_customizeEmit01.hideInfo(compid+"_infocorpName_black");
					FrontMessages_customizeEmit01.displayInfo(compid+"_infocorpName");
				}
			}
		//选择分类
		if(item=="all"||item=="messagesCategoryId"){
			if(form.messagesCategoryId){
				FrontMessages_customizeEmit01.showinfo(compid+"_messagesCategoryId");
			    if(document.getElementById("messagesCategoryId").selectedIndex==0){
					FrontMessages_customizeEmit01.displayInfo(compid+"_errmessagesCategoryId");
					isSub=false;
			    }
			}	
			
	    }
	    if((item=="all"||item=="content")&&form.content){
		    if (/^\s*$/.test(form.content.value)) {
	    			FrontMessages_customizeEmit01.hideInfo(compid+"_infocontent");
	    			FrontMessages_customizeEmit01.hideInfo(compid+"_infocontent_black");
		 			FrontMessages_customizeEmit01.hideInfo(compid+"_errcontent");
					FrontMessages_customizeEmit01.displayInfo(compid+"_nocontent");
					isSub=false;
		       }else if(form.content.value.length >form.maxContent.value){
		        	FrontMessages_customizeEmit01.hideInfo(compid+"_infocontent");
		        	FrontMessages_customizeEmit01.hideInfo(compid+"_infocontent_black");
		 			FrontMessages_customizeEmit01.hideInfo(compid+"_nocontent");
					FrontMessages_customizeEmit01.displayInfo(compid+"_errcontent");
					isSub=false;
		    }
		    if(isSub==true){
				FrontMessages_customizeEmit01.hideInfo(compid+"_infocontent_black");
				FrontMessages_customizeEmit01.displayInfo(compid+"_infocontent");
			}
	    }

	/*if((item=="all"||item=="messagesTitle")&&form.messagesTitle){
			form.messagesTitle.value = form.messagesTitle.value.replace(/^\s+|\s+$/g, "");
			if(form.isDisplayMessagesTitle.value=='1'){
				if (/^\s*$/.test(form.messagesTitle.value)) {
					FrontMessages_customizeEmit01.displayInfo(compid+"_nomessagesTitle");
					
					isSub=false;
				}
			}
		}*/
		if((item=="all"||item=="messagesTitle")&&form.messagesTitle){
			form.messagesTitle.value = form.messagesTitle.value.replace(/^\s+|\s+$/g, "");
               //首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
			   	if (!/^\s*$/.test(form.messagesTitle.value)) {
			    	if(specialCharactersCheck(form.messagesTitle.value)){
			    		FrontMessages_customizeEmit01.hideInfo(compid+"_infomessagesTitle");
			    		FrontMessages_customizeEmit01.hideInfo(compid+"_infomessagesTitle_black");
				 		FrontMessages_customizeEmit01.hideInfo(compid+"_nomessagesTitle");
						FrontMessages_customizeEmit01.displayInfo(compid+"_errmessagesTitle");
						isSub=false;
			    	}
	    		}
	    		
			if(form.isDisplayMessagesTitle.value=='1'){
				if (/^\s*$/.test(form.messagesTitle.value)) {
					FrontMessages_customizeEmit01.hideInfo(compid+"_infomessagesTitle");
		    		FrontMessages_customizeEmit01.hideInfo(compid+"_infomessagesTitle_black");
			 		FrontMessages_customizeEmit01.hideInfo(compid+"_errmessagesTitle");
					FrontMessages_customizeEmit01.displayInfo(compid+"_nomessagesTitle");
					isSub=false;
				}
			}
            if(isSub==true){
				FrontMessages_customizeEmit01.hideInfo(compid+"_infomessagesTitle_black");
				FrontMessages_customizeEmit01.displayInfo(compid+"_infomessagesTitle");
			}
		}
	    
	    
		/*if((item=="all"||item=="weburl")&&form.weburl){
			var netStr =/^((http|https|ftp):(\/\/|\\\\))?((\w)+[.]){1,}/;
			if(form.isDisplayUrl.value=='1'){
				if(form.weburl.value==""||form.weburl.value=="http://"){
					FrontMessages_customizeEmit01.displayInfo(compid+"_noweburl");
		            isSub=false;
				 }else if (!netStr.test(form.weburl.value)){
		            FrontMessages_customizeEmit01.displayInfo(compid+"_errweburl");
		            isSub=false;
		        }
			}else {
				 if(form.weburl.value!=""&&form.weburl.value!="http://"){
					 if (!netStr.test(form.weburl.value)){
			            FrontMessages_customizeEmit01.displayInfo(compid+"_errweburl");
			            isSub=false;
			         }
		         }
			}
		}*/
		if((item=="all"||item=="weburl")&&form.weburl){
			var netStr =/^((http|https|ftp):(\/\/|\\\\))?((\w)+[.]){1,}/;
			if(form.isDisplayUrl.value=='1'){
				if(form.weburl.value==""||form.weburl.value=="http://"){
				    FrontMessages_customizeEmit01.hideInfo(compid+"_infoweburl");
		    		FrontMessages_customizeEmit01.hideInfo(compid+"_infoweburl_black");
			 		FrontMessages_customizeEmit01.hideInfo(compid+"_errweburl");
					FrontMessages_customizeEmit01.displayInfo(compid+"_noweburl");
		            isSub=false;
				 }else if (!netStr.test(form.weburl.value)){
				    FrontMessages_customizeEmit01.hideInfo(compid+"_infoweburl");
		    		FrontMessages_customizeEmit01.hideInfo(compid+"_infoweburl_black");
			 		FrontMessages_customizeEmit01.hideInfo(compid+"_errweburl");
		            FrontMessages_customizeEmit01.displayInfo(compid+"_errweburl");
		            isSub=false;
		        }
			}else {
				 if(form.weburl.value!=""&&form.weburl.value!="http://"){
					 if (!netStr.test(form.weburl.value)){
					    FrontMessages_customizeEmit01.hideInfo(compid+"_infoweburl");
			    		FrontMessages_customizeEmit01.hideInfo(compid+"_infoweburl_black");
				 		FrontMessages_customizeEmit01.hideInfo(compid+"_errweburl");
			            FrontMessages_customizeEmit01.displayInfo(compid+"_errweburl");
			            isSub=false;
			         }
		         }
			}
			  if(isSub==true){
				FrontMessages_customizeEmit01.hideInfo(compid+"_infoweburl_black");
				FrontMessages_customizeEmit01.displayInfo(compid+"_infoweburl");
			}
		}
		if(item=="all"||item=="verifyCode"){
			if (form.verifyCode.value.length ==0) {
			    FrontMessages_customizeEmit01.hideInfo(compid+"_pastverifyCode");
			 	FrontMessages_customizeEmit01.hideInfo(compid+"_errverifyCode");
				FrontMessages_customizeEmit01.displayInfo(compid+"_noverifyCode");
				isSub=false;
			}
		}
		if(item=="all"||attributeType=="0"){
			// 所有字符
			if(attributeConstraint=="0"){
				document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
	    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
	    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
				if(isDisplayAttribute=='1'){
			    	if (/^\s*$/.test(extendAtrributeValue)) {
			    	
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
						isSub=false;
			    	}
		    	}
			}
			// email地址
			if(attributeConstraint=="1"){
				document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
	    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
	    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
	    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
		    	if (!/^\s*$/.test(extendAtrributeValue)) {
			    	if (!isEmail(extendAtrributeValue)) {
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
						isSub=false;
			    	}
	    		}
		    	if(isDisplayAttribute=='1'){
			    	if (/^\s*$/.test(extendAtrributeValue)) {
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
						isSub=false;
			    	}
		    	}
				if(isSub==true){
					FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
				}
			}
			// 手机
			if(attributeConstraint=="2"){
				document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
	    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
	    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
	    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
		    	if (!/^\s*$/.test(extendAtrributeValue)) {
			    	if (!isMobileNumber(extendAtrributeValue)) {
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
						isSub=false;
			    	}
	    		}
		    	if(isDisplayAttribute=='1'){
			    	if (/^\s*$/.test(extendAtrributeValue)) {
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
						isSub=false;
			    	}
		    	}
				if(isSub==true){
					FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
				}
			}
			// 电话
			if(attributeConstraint=="3"){
				document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
	    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
	    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
	    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
		    	if (!/^\s*$/.test(extendAtrributeValue)) {
			    	if (!FrontMessages_customizeEmit01.isValidPhone(extendAtrributeValue)) {
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
						isSub=false;
			    	}
	    		}
		    	if(isDisplayAttribute=='1'){
			    	if (/^\s*$/.test(extendAtrributeValue)) {
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
						isSub=false;
			    	}
		    	}
				if(isSub==true){
					FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
				}
			}
			// 邮编
			if(attributeConstraint=="4"){
				zip = /^\d{6}$/
				document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
	    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
	    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
	    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
		    	if (!/^\s*$/.test(extendAtrributeValue)) {
			    	if (!zip.test(extendAtrributeValue)) {
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
						isSub=false;
			    	}
	    		}
		    	if(isDisplayAttribute=='1'){
			    	if (/^\s*$/.test(extendAtrributeValue)) {
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
						isSub=false;
			    	}
		    	}
				if(isSub==true){
					FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
				}
			}
			// 身份证
			if(attributeConstraint=="5"){
				document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
	    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
	    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
	    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
		    	if (!/^\s*$/.test(extendAtrributeValue)) {
			    	if (!FrontMessages_customizeEmit01.isIdCard(extendAtrributeValue)) {
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
						isSub=false;
			    	}
	    		}
		    	if(isDisplayAttribute=='1'){
			    	if (/^\s*$/.test(extendAtrributeValue)) {
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
						isSub=false;
			    	}
		    	}
				if(isSub==true){
					FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
				}
			}
			// 网站地址
			if(attributeConstraint=="6"){
			    netStr =/^((http|https|ftp):(\/\/|\\\\))?((\w)+[.]){1,}/;
				document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
	    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
	    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
	    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
		    	if(isDisplayAttribute=='1'){
					if(extendAtrributeValue==""||extendAtrributeValue=="http://"){
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
			            isSub=false;
					 }else if (!netStr.test(extendAtrributeValue)){
			            FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
			            isSub=false;
			        }
				}else {
					 if(extendAtrributeValue!=""&&extendAtrributeValue!="http://"){
						 if (!netStr.test(extendAtrributeValue)){
						     FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
							 FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
							 FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
					         isSub=false;
				         }
			         }
				}
				if(isSub==true){
					FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
				}
			}
			// qq
			if(attributeConstraint=="7"){
				qq = /^[1-9]\d{4,9}$/
				document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
	    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
	    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
	    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
		    	if (!/^\s*$/.test(extendAtrributeValue)) {
			    	if (!qq.test(extendAtrributeValue)) {
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
						isSub=false;
			    	}
	    		}
		    	if(isDisplayAttribute=='1'){
			    	if (/^\s*$/.test(extendAtrributeValue)) {
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
						isSub=false;
			    	}
		    	}
				if(isSub==true){
					FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
				}
			}
			// 整数
			if(attributeConstraint=="8"){
				str = /^[-]{0,1}[0-9]{1,}$/;
				document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
	    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
	    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
	    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
		    	if (!/^\s*$/.test(extendAtrributeValue)) {
			    	if (!str.test(extendAtrributeValue)) {
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
						isSub=false;
			    	}
	    		}
		    	if(isDisplayAttribute=='1'){
			    	if (/^\s*$/.test(extendAtrributeValue)) {
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
						isSub=false;
			    	}
		    	}
				if(isSub==true){
					FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
				}
			}
			// 数字
			if(attributeConstraint=="9"){
				str = /^(-?\d+)(\.\d+)?$/;
				document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
	    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
	    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
	    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
		    	if (!/^\s*$/.test(extendAtrributeValue)) {
			    	if (!str.test(extendAtrributeValue)) {
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
						isSub=false;
			    	}
	    		}
		    	if(isDisplayAttribute=='1'){
			    	if (/^\s*$/.test(extendAtrributeValue)) {
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
						isSub=false;
			    	}
		    	}
				if(isSub==true){
					FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
					FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
				}
			}
			
		}
		//多行文本验证
		if(item=="all"||attributeType=="1"){
			if(document.getElementById("extendAtrribute"+item)&&document.getElementById("isDisplayAttribute"+item)){
				document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
		    	extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
		    	isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value
		    	attributeMaxContent = document.getElementById("maxContent"+item).value
				if (/^\s*$/.test(extendAtrributeValue)&&isDisplayAttribute=='1') {
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
						FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
						isSub=false;
			       }else if(extendAtrributeValue.length >attributeMaxContent){
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
						FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
						isSub=false;
			    }
			    if(isSub==true){
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
						FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
				}
			}
		}
		//选项
		if(item=="all"||attributeType=="2"){
			if(document.getElementById("isDisplayAttribute"+item)){
		    	//是否必填的标志
				isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value
				if(document.getElementById("extendAtrribute"+item)){
					extendAtrribute=document.getElementById("extendAtrribute"+item);
				}
				//判断单选是否必填
				option = document.getElementsByName("extendAtrribute"+item);
				//判断复选是否必填
				arrCheckbox = document.getElementsByName("checkboxExtendAtrribute"+item);
				if(arrCheckbox.length>0){
					//复选判断是否必填所用
					option = document.getElementsByName("checkboxExtendAtrribute"+item);
				}
		    	if(isDisplayAttribute=='1'){
		    		var flag = false;
			    	for(i=0;i<option.length;i++){
			    		if(option[i].checked){
			    			flag = true;
			    		}
			    	}
			    	if(extendAtrribute.type=="select-one"){
						if(extendAtrribute.selectedIndex!=0){
							flag = true;
						}
					}
			    	if(!flag){
			    		FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
						FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
						FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
						isSub=false;
			    	}else{
			    		FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
						FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
			    	}
		    	}
	    	}
	    	
		}
		//日期时间
		if(item=="all"||attributeType=="3"){
			if(document.getElementById("extendAtrribute"+item)&&document.getElementById("isDisplayAttribute"+item)){
				document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
		    	extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
		    	isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value
				if(isDisplayAttribute=='1'){
				    if (/^\s*$/.test(extendAtrributeValue)) {
						 FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
						 FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
						 FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
						 FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
						 isSub=false;
				    }
			    }
			    //判断字符串格式
			    
		    }
		}
		if(item=="all"){
			arrAttribute = document.getElementsByName(compid+"_isDisplayAttribute");
			
			//自定义验证
			//单行文本验证
			for(i=0;i<arrAttribute.length;i++){
				otherAttribute=arrAttribute[i].getAttribute("otherAttribute");
				allOtherAttribute = otherAttribute.split("_attribute_");
				attributeType=allOtherAttribute[0];
				attributeConstraint=allOtherAttribute[1];
				item=arrAttribute[i].id.substr(18,arrAttribute[i].id.length);
				if(item=="all"||attributeType=="0"){
					// 所有字符
					if(attributeConstraint=="0"){
					
						document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
			    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
			    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
						if(isDisplayAttribute=='1'){
					    	if (/^\s*$/.test(extendAtrributeValue)) {
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
								isSub=false;
					    	}
				    	}
					}
					// email地址
					if(attributeConstraint=="1"){
						document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
			    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
			    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
			    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
				    	if (!/^\s*$/.test(extendAtrributeValue)) {
					    	if (!isEmail(extendAtrributeValue)) {
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
								isSub=false;
					    	}
			    		}
				    	if(isDisplayAttribute=='1'){
					    	if (/^\s*$/.test(extendAtrributeValue)) {
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
								isSub=false;
					    	}
				    	}
						if(isSub==true){
							FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
						}
					}
					// 手机
					if(attributeConstraint=="2"){
						document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
			    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
			    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
			    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
				    	if (!/^\s*$/.test(extendAtrributeValue)) {
					    	if (!isMobileNumber(extendAtrributeValue)) {
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
								isSub=false;
					    	}
			    		}
				    	if(isDisplayAttribute=='1'){
					    	if (/^\s*$/.test(extendAtrributeValue)) {
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
								isSub=false;
					    	}
				    	}
						if(isSub==true){
							FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
						}
					}
					// 电话
					if(attributeConstraint=="3"){
						document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
			    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
			    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
			    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
				    	if (!/^\s*$/.test(extendAtrributeValue)) {
					    	if (!FrontMessages_customizeEmit01.isValidPhone(extendAtrributeValue)) {
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
								isSub=false;
					    	}
			    		}
				    	if(isDisplayAttribute=='1'){
					    	if (/^\s*$/.test(extendAtrributeValue)) {
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
								isSub=false;
					    	}
				    	}
						if(isSub==true){
							FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
						}
					}
					// 邮编
					if(attributeConstraint=="4"){
						zip = /^\d{6}$/
						document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
			    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
			    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
			    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
				    	if (!/^\s*$/.test(extendAtrributeValue)) {
					    	if (!zip.test(extendAtrributeValue)) {
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
								isSub=false;
					    	}
			    		}
				    	if(isDisplayAttribute=='1'){
					    	if (/^\s*$/.test(extendAtrributeValue)) {
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
								isSub=false;
					    	}
				    	}
						if(isSub==true){
							FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
						}
					}
					// 身份证
					if(attributeConstraint=="5"){
						document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
			    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
			    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
			    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
				    	if (!/^\s*$/.test(extendAtrributeValue)) {
					    	if (!FrontMessages_customizeEmit01.isIdCard(extendAtrributeValue)) {
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
								isSub=false;
					    	}
			    		}
				    	if(isDisplayAttribute=='1'){
					    	if (/^\s*$/.test(extendAtrributeValue)) {
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
								isSub=false;
					    	}
				    	}
						if(isSub==true){
							FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
						}
					}
					// 网站地址
					if(attributeConstraint=="6"){
					    netStr =/^((http|https|ftp):(\/\/|\\\\))?((\w)+[.]){1,}/;
						document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
			    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
			    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
			    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
				    	if(isDisplayAttribute=='1'){
							if(extendAtrributeValue==""||extendAtrributeValue=="http://"){
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
					            isSub=false;
							 }else if (!netStr.test(extendAtrributeValue)){
					            FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
					            isSub=false;
					        }
						}else {
							 if(extendAtrributeValue!=""&&extendAtrributeValue!="http://"){
								 if (!netStr.test(extendAtrributeValue)){
								     FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
									 FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
									 FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
									 FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
							         isSub=false;
						         }
					         }
						}
						if(isSub==true){
							FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
						}
					}
					// qq
					if(attributeConstraint=="7"){
						qq = /^[1-9]\d{4,9}$/
						document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
			    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
			    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
			    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
				    	if (!/^\s*$/.test(extendAtrributeValue)) {
					    	if (!qq.test(extendAtrributeValue)) {
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
								isSub=false;
					    	}
			    		}
				    	if(isDisplayAttribute=='1'){
					    	if (/^\s*$/.test(extendAtrributeValue)) {
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
								isSub=false;
					    	}
				    	}
						if(isSub==true){
							FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
						}
					}
					// 整数
					if(attributeConstraint=="8"){
						str = /^[-]{0,1}[0-9]{1,}$/;
						document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
			    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
			    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
			    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
				    	if (!/^\s*$/.test(extendAtrributeValue)) {
					    	if (!str.test(extendAtrributeValue)) {
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
								isSub=false;
					    	}
			    		}
				    	if(isDisplayAttribute=='1'){
					    	if (/^\s*$/.test(extendAtrributeValue)) {
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
								isSub=false;
					    	}
				    	}
						if(isSub==true){
							FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
						}
					}
					// 数字
					if(attributeConstraint=="9"){
						str = /^(-?\d+)(\.\d+)?$/;
						document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
			    		extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
			    		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value;
			    		//首先判断是否为空，如果为空则不判断了，如果不为空则判断一下是否合理。
				    	if (!/^\s*$/.test(extendAtrributeValue)) {
					    	if (!str.test(extendAtrributeValue)) {
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
								isSub=false;
					    	}
			    		}
				    	if(isDisplayAttribute=='1'){
					    	if (/^\s*$/.test(extendAtrributeValue)) {
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							 	FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
								isSub=false;
					    	}
				    	}
						if(isSub==true){
							FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
							FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
						}
					}
					
				}
				//多行文本验证
				if(item=="all"||attributeType=="1"){
					if(document.getElementById("extendAtrribute"+item)&&document.getElementById("isDisplayAttribute"+item)){
						document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
				    	extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
				    	isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value
				    	attributeMaxContent = document.getElementById("maxContent"+item).value
						if (/^\s*$/.test(extendAtrributeValue)&&isDisplayAttribute=='1') {
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
								FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
								isSub=false;
					       }else if(extendAtrributeValue.length >attributeMaxContent){
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
								FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
								isSub=false;
					    }
					    if(isSub==true){
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
								FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
						}
					}
				}

				//选项
				if(item=="all"||attributeType=="2"){
					if(document.getElementById("isDisplayAttribute"+item)){
						//是否必填的标志
						isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value
						if(document.getElementById("extendAtrribute"+item)){
							extendAtrribute=document.getElementById("extendAtrribute"+item);
						}
						//判断单选是否必填将选择的内容存储
				    	option = document.getElementsByName("extendAtrribute"+item);
						//复选将所有的值以字符串的格式存储
						arrCheckbox = document.getElementsByName("checkboxExtendAtrribute"+item);
						if(arrCheckbox.length>0){
							strCheckbox = "";
							for(m=arrCheckbox.length-1;m>=0;m--){
						    	if(arrCheckbox[m].checked){
						    		strCheckbox = arrCheckbox[m].value+","+strCheckbox;
						    	}
							}
							strCheckbox = strCheckbox.substr(0,strCheckbox.length-1);
							//复选框的最终值
							extendAtrribute.value = strCheckbox;
							//复选判断是否必填所用
							option = document.getElementsByName("checkboxExtendAtrribute"+item);
						}
						
					    if(isDisplayAttribute=='1'){
					    	var flag = false;
						    for(j=0;j<option.length;j++){
						    	if(option[j].checked){
						    		flag = true;
						    	}
						   	}
						    if(extendAtrribute.type=="select-one"){
							   	if(extendAtrribute.selectedIndex!=0){
									flag = true;
							    }
						   	}
						   	if(!flag){
						   		FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
								FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
								FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
								isSub=false;
					    	}else{
					    		FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
								FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
					    	}
					   	}
			    	}
				}
				//日期时间
				
				if(item=="all"||attributeType=="3"){
					if(document.getElementById("extendAtrribute"+item)&&document.getElementById("isDisplayAttribute"+item)){
						document.getElementById("extendAtrribute"+item).value=document.getElementById("extendAtrribute"+item).value.replace(/^\s+|\s+$/g, "");
				    	extendAtrributeValue=document.getElementById("extendAtrribute"+item).value;
				    	isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value
						if(isDisplayAttribute=='1'){
						    if (/^\s*$/.test(extendAtrributeValue)) {
								 FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
								 FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
								 FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
								 FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
								 isSub=false;
						    }
					    }
				    }
				}
			}
		}
		if(!form.content){
			isSub=false;
		}
		//isSub=false;
		if(isSub&&subitem=="all"){
			form.orignal_url.value = window.location.href;
			document.getElementById(compid+"_submit").disabled='disabled';
			form.submit();
		}
	},
	
	/**
	 * 选择表情。
	 *
	 * @param e 被选择的表情
	 * @return
	 */
	selectEmotion:function(e,compid){
		var firstSrc=e.src;
		var secondSrc=firstSrc.replace("mesa-","mes-"); 
		var eleEmotion = document.getElementById(compid+"_emotion");
		var imageId = document.getElementById(compid+"_imageId");
		//先将以前选中的图片效果清除
		if(imageId.value !=null && imageId.value !=""){
			var oldimg = document.getElementById(imageId.value);
			oldimg.src=imageId.name;
		}
		
		//将当前选中的图片加样式效果
		//e.className="imgstyle2";
		e.src=secondSrc;
		//获取图片SRC
		var imgSrc = e.src;
		imgSrc = imgSrc.substring(imgSrc.lastIndexOf("/")+1);
		eleEmotion.value = imgSrc;
		document.getElementById(compid+"_imageId").value = e.id;
		if(imageId.name.substring(imageId.name.length-6,imageId.name.length)!=e.src.substring(e.src.length-6,e.src.length)){
			document.getElementById(compid+"_imageId").name = firstSrc;
		}
		document.getElementById(compid+"_emotion").value = e.name;
		
	},
	/**
	 * 提取是否邮件联系。
	 *
	 * @param obj 
	 * @param compid
	 * @return
	 */
	addIsByMailValue:function(obj,compid){
		FrontMessages_customizeEmit01.hideInfo(compid+"_infomail_black");
		FrontMessages_customizeEmit01.hideInfo(compid+"_nomail");
		FrontMessages_customizeEmit01.hideInfo(compid+"_errmail");
		FrontMessages_customizeEmit01.displayInfo(compid+"_infomail");
		if(obj.checked){
			$("#isByMail").attr("value","1");
		}else{
			$("#isByMail").attr("value","0");
		}
	},
	/**
	 * 提取是否短信联系。
	 *
	 * @param obj 
	 * @param compid
	 * @return
	 */
	addIsByNoteValue:function(obj,compid){
		FrontMessages_customizeEmit01.hideInfo(compid+"_infomobile_black");
		FrontMessages_customizeEmit01.hideInfo(compid+"_nomobile");
		FrontMessages_customizeEmit01.hideInfo(compid+"_errmobile");
		FrontMessages_customizeEmit01.displayInfo(compid+"_infomobile");
		if(obj.checked){
			$("#isByNote").attr("value","1");
		}else{
			$("#isByNote").attr("value","0");
		}
	},
  
	/**
	 * 判断字符串中是否都是数字,返回true则不全是数字，返回false 则全是数字。
	 *
	 * @param String 字符串
	 * @return 
	 */
	checknumber:function(String){ 
		var Letters = "1234567890"; 
		var i; 
		var c; 
		for( i = 0; i < String.length; i ++ ){ 
			c = String.charAt( i ); 
			if (Letters.indexOf( c ) ==-1){ 
				return true; 
			} 
		} 
		return false; 
	},
	/**
	 * 会员表单自动填写。
	 *
	 * @param data 已经填写好的表单的数据
	 * @return
	 */
	callback:function(data)
	{
		arrsp=data.split("***");
	 	authorarr=arrsp[0].split(":");
	 	authorarr[1]=authorarr[1].substr(1, authorarr[1].length-2); 
		$("#mail").attr("value",authorarr[1]==null?'': authorarr[1]);
		if(data['mail'] != null)
		{
			$('#mail').attr("readonly","true");
		}
		authorarr=arrsp[1].split(":");
		authorarr[1]=authorarr[1].substr(1, authorarr[1].length-2); 
		$("#author").attr("value",authorarr[1]==null?'': authorarr[1]);
		authorarr=arrsp[3].split(":");
		authorarr[1]=authorarr[1].substr(1, authorarr[1].length-2); 
		$("#phone").attr("value",authorarr[1]==null?'': authorarr[1]);
		authorarr=arrsp[4].split(":");
		authorarr[1]=authorarr[1].substr(1, authorarr[1].length-2); 
		$("#mobile").attr("value",authorarr[1]==null?'': authorarr[1]);
		authorarr=arrsp[7].split(":");
		authorarr[1]=authorarr[1].substr(1, authorarr[1].length-2); 
		$("#address").attr("value",authorarr[1]==null?'': authorarr[1]);
		authorarr=arrsp[8].split(":");
		authorarr[1]=authorarr[1].substr(1, authorarr[1].length-2); 
		$("#corpName").attr("value",authorarr[1]==null?'': authorarr[1]);
	
		authorarr=arrsp[2].split(":");
		authorarr[1]=authorarr[1].substr(1, authorarr[1].length-2); 
		if(authorarr[1] != null && authorarr[1] == '0')
			$('#sex1').attr("checked","checked");
	
		else if (authorarr[1] != null && authorarr[1] == '1')
		{
			$('#sex2').attr("checked","checked");
		}
	
		if(data['isByMail'] != null && data['isByMail'] == '0')
			$('#isByMail2').attr("checked","checked");
		else if (data['isByMail'] != null && data['isByMail'] == '1')
		{
			$('#isByMail1').attr("checked","checked");
		}
		if(data['isByNote'] != null && data['isByNote'] == '0')
				$('#isByNote2').attr("checked","checked");
		else if (data['isByNote'] != null && data['isByNote'] == '1')
		{
			$('#isByNote1').attr("checked","checked");
		}
	
	},
	/**
	* 动态显示留言字数
	* 参数 formId 表单id , obj 留言页面对象
	*/
	dynamicNum:function(formId,obj,item){
	  		var lBrowser = {};
			lBrowser.agt = navigator.userAgent.toLowerCase();
			lBrowser.isW3C = document.getElementById ? true:false;
			lBrowser.isIE = ((lBrowser.agt.indexOf("msie") != -1) && (lBrowser.agt.indexOf("opera") == -1) && (lBrowser.agt.indexOf("omniweb") == -1));
			lBrowser.isNS6 = lBrowser.isW3C && (navigator.appName=="Netscape") ;
			lBrowser.isOpera = lBrowser.agt.indexOf("opera") != -1;
			lBrowser.isGecko = lBrowser.agt.indexOf("gecko") != -1;
			lBrowser.ieTrueBody =function (){
			  return (document.compatMode && document.compatMode!="BackCompat")? document.documentElement : document.body;
			};
		
			//为Firefox下的DOM对象增加innerText属性  ff下无innerText属性 有等同效果的textContent属性
			if(lBrowser.isNS6){ //firefox innerText define
			 HTMLElement.prototype.__defineGetter__( "innerText",
				 function(){
				 	return this.textContent;
				 }
			 );
			 HTMLElement.prototype.__defineSetter__( "innerText",
				 function(sText){
				 	this.textContent=sText;
			 	 }
			 );
			}
	
			
	  	  var formObj = document.getElementById(formId);
	  	  if(item=="null"){
	  	  var dynamicNum = document.getElementById('dynamicNum');
	  	  }else{
	  	  var dynamicNum = document.getElementById('dynamicNum'+item);
	  	  }
	  	  var num = obj.value;
	  	  dynamicNum.innerText = num.length;
	  },
	/**
	 * 提取星级设置。
	 *
	 * @param parameter
	 * @return
	 */
	setStarValue:function(parameter){
		document.getElementById("star").value=parameter.innerHTML;
	},	
	/**
	 * ajax验证码替换。
	 *
	 * @return
	 */
	getajaxverifyCode:function(){
		$.get("/FrontMessages.do?method=getVerifyCode",
		 function(data){
		 if($("#ajaxverifyCode").attr("value")==data){
		 	FrontMessages_customizeEmit01.getajaxverifyCode();
		 }else{
		 	$("#ajaxverifyCode").attr("value",data);
		 }
		});
	},
	/**
	 * ajax验证码提取。
	 *
	 * @return
	 */
	getajaxverifyCodeforonblur:function(){
		$.get("/FrontMessages.do?method=getVerifyCode",
		 function(data){
		 if($("#ajaxverifyCode").attr("value")!=data){
		 	$("#ajaxverifyCode").attr("value",data);
		 }
		});
	},	
	/**
	 * 当鼠标划过显示手型。
	 *
	 * @return
	 */
	showHand:function(objthis){
		objthis.style.cursor = 'pointer';
	},
	/**
	 * 验证码校验。
	 *
	 * @return
	 */
	chkverifyCode:function(objid,compid){
		 if (objid=="0") {
			FrontMessages_customizeEmit01.hideInfo(compid+"_errverifyCode");
			FrontMessages_customizeEmit01.hideInfo(compid+"_noverifyCode");
			FrontMessages_customizeEmit01.displayInfo(compid+"_pastverifyCode");

		 }else if (objid=="1") {
			FrontMessages_customizeEmit01.hideInfo(compid+"_pastverifyCode");
			FrontMessages_customizeEmit01.hideInfo(compid+"_noverifyCode");
			FrontMessages_customizeEmit01.displayInfo(compid+"_errverifyCode");
		 }
	},
	/**
	 * 根据状态是否显示提示信息 divName 层对象 divName2 层对象 divName3 层对象 status 是否显示 1为显示 其他为隐藏
	 */
	displayDiv : function(divName, status, divName2, divName3) {
		var divObj = document.getElementById(divName);
		if (null != divObj) {
			if (status == 1) {
				divObj.style.display = '';
			} else {
				divObj.style.display = 'none';
			}
		}

		var divObj = document.getElementById(divName2);
		if (null != divObj) {
			if (status == 1) {
				divObj.style.display = '';
			} else {
				divObj.style.display = 'none';
			}
		}

		var divObj = document.getElementById(divName3);
		if (null != divObj) {
			if (status == 1) {
				divObj.style.display = '';
			} else {
				divObj.style.display = 'none';
			}
		}

	},

	/**
	 * 校验出生日期。
	 * 
	 * @param compId
	 * @param form
	 *            表单对象。
	 * @return
	 */
	checkBirthDay : function(compid, form, item) {
		attributeDate = document.getElementById("extendAtrribute"+item);
		isDisplayAttribute=document.getElementById("isDisplayAttribute"+item).value
		if (!isDate(trim(attributeDate.value), true)) {
			attributeDate.value="";
		}
		if(isDisplayAttribute=='1'){
			if (isNull(attributeDate.value)
						|| trim(attributeDate.value) == "yyyy-mm-dd"
						|| trim(attributeDate.value) == "YYYY-MM-DD") {
				FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
				FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
				FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
				FrontMessages_customizeEmit01.displayInfo(compid+"_no"+item);
					// birthday.focus();
				return false;
			}
			if (!isDate(trim(attributeDate.value), true)) {
				FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item);
				FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
				FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
				FrontMessages_customizeEmit01.displayInfo(compid+"_err"+item);
				// birthday.focus();
				return false;
			}
			FrontMessages_customizeEmit01.hideInfo(compid+"_err"+item);
			FrontMessages_customizeEmit01.hideInfo(compid+"_no"+item);
			FrontMessages_customizeEmit01.hideInfo(compid+"_info"+item+"_black");
			FrontMessages_customizeEmit01.displayInfo(compid+"_info"+item);
		}
		return true;
	}
}

var FrontLinks_list01={setClickTimes:function(a){$.post("/FrontLinks.do","method=setClickTimes&linkId="+a)}};