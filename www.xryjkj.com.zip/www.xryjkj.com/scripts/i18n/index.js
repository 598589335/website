var i18n_FrontGallery_detail01_page_invalidnumber="您输入的页数不正确！";
var i18n_FrontGallery_detail01_page_tupian="图片";
var i18n_FrontGallery_detail01_page_picdesc="图片描述：";
var i18n_FrontGallery_detail01_page_pictureName="图片名称：";